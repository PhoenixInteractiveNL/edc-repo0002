/*
 *
 * Copyright (C) 2004-2005 Robert Bryon Vandiver (asterick@buxx.com)
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Minimon.rc
//
#define ID_MEMORY_SYMBOL                0
#define ID_REGACCESS_VIEWER             1122
#define ID_BREAK_SYMBOL                 1
#define IDI_MENU                        4
#define IDI_MAIN                        9
#define ID_OPEN                         102
#define ID_ABOUT                        104
#define ID_RELOAD                       105
#define ID_SAVE                         106
#define ID_SAVE_AS                      107
#define IDB_SMALLFONT                   118
#define IDR_ACCELERATOR                 120
#define IDD_CPUSTAT                     122
#define IDD_ABOUT                       123
#define ID_WATCH_SHOW                   128
#define ID_WATCH_VIEWER                 128
#define ID_WATCH_DELETE                 130
#define ID_BREAK_SHOW                   131
#define ID_BREAK_VIEWER                 131
#define ID_BREAK_ENABLE                 132
#define ID_BREAK_DELETE                 133
#define ID_BREAK_TOGGLE                 134
#define ID_WATCH_TOGGLE                 135
#define ID_STEP_OPCODE                  136
#define ID_STEP_CYCLES                  137
#define ID_STEP_FRAME                   138
#define ID_BREAK_ADDRESS                139
#define ID_BREAK_IRQ_BIOS               141
#define ID_RESET                        146
#define ID_FORCE_IRQ                    148
#define ID_RUN_FULL                     149
#define ID_RUN_DEBUG                    150
#define ID_RUN_ADDRESS                  153
#define ID_RUN_SYMBOL                   154
#define ID_DISASSEMBLE_PC               161
#define ID_DISASSEMBLE_BOTH             162
#define ID_MEMORY_BIOS                  165
#define ID_MEMORY_REGISTERS             166
#define ID_DISASSEMBLE_USER             169
#define ID_BREAK_IRQ_ROM                171
#define ID_SYMBOLS_LOAD                 172
#define ID_SYMBOLS_VIEWER               173
#define ID_REGISTER_VIEWER              177
#define ID_TILE_VIEWER                  178
#define ID_MAP_VIEWER                   181
#define ID_SPRITE_VIEW                  182
#define ID_SPRITE_VIEWER                182
#define ID_OAM_VIEWER                   183
#define ID_MEMORY_RAM                   184
#define ID_MEMORY_ROM                   185
#define IDI_SMALLICO                    186
#define ID_STOP                         188
#define ID_WATCH_ADDRESS                190
#define ID_WATCH_SYMBOL                 191
#define ID_BREAK_DELALL                 192
#define ID_BREAK_DELETE_ALL             192
#define ID_WATCH_DELALL                 193
#define ID_WATCH_DELETE_ALL             193
#define ID_SYMBOLS_SAVE                 195
#define ID_SYMBOLS_SAVE_AS              196
#define ID_CLOSE                        197
#define IDD_REQUEST_INT                 198
#define IDS_CYCLES                      199
#define IDS_IRQ                         200
#define ID_WATCH_MANAGE                 200
#define IDS_ADDRESS                     201
#define ID_BREAK_MANAGE                 201
#define IDD_REQUEST_SYM                 202
#define IDS_WATCH                       202
#define ID_MEMORY_ADDRESS               203
#define IDS_VALUE                       203
#define ID_SYMBOLS_DELETE               204
#define ID_SYMBOLS_ADD                  205
#define ID_CONFIG_INPUT                 206
#define IDD_CFGINPUT                    207
#define ID_ENABLE_DEBUGGER              208
#define ID_LCD_1                        209
#define ID_LCD_2                        210
#define ID_LCD_3                        211
#define ID_LCD_4                        212
#define ID_SHOW_CONSOLE                 213
#define IDD_ADD_SYMBOL                  214
#define IDD_MEMORY                      215
#define ID_DISASSEMBLER_JUMP_ADDR       216
#define ID_DISASSEMBLER_JUMP_PC         217
#define IDD_OPCODE                      218
#define ID_AUDIO_ENABLE                 219
#define ID_MASK_VIDEO                   220
#define ID_VIDEO_PLAIN                  221
#define ID_DOT_MASK                     222
#define ID_HQ2X                         223
#define ID_HQ3X                         224
#define ID_HQ4X                         225
#define ID_INTERLEAVE                   226
#define ID_Menu                         227
#define ID_EMULATE_GRAY                 228
#define ID_PC                           1060
#define ID_SP                           1061
#define ID_BA                           1062
#define ID_HL                           1063
#define ID_X                            1064
#define ID_Y                            1065
#define ID_U                            1066
#define ID_F                            1067
#define ID_B                            1068
#define ID_H                            1069
#define ID_XI                           1070
#define ID_YI                           1071
#define ID_V                            1072
#define ID_E                            1073
#define ID_A                            1074
#define ID_L                            1075
#define ID_I                            1076
#define ID_N                            1077
#define ID_F1                           1078
#define ID_F2                           1079
#define ID_F3                           1080
#define ID_F4                           1081
#define ID_F5                           1082
#define ID_F6                           1083
#define ID_F7                           1084
#define ID_F8                           1085
#define ID_E1                           1086
#define ID_E2                           1087
#define ID_E3                           1088
#define ID_E4                           1089
#define ID_E5                           1090
#define ID_E6                           1091
#define ID_E7                           1092
#define ID_E8                           1093
#define ID_CLOCK                        1095
#define IDC_LCD                         1096
#define IDC_NAME                        1096
#define IDC_TILES                       1098
#define IDC_VALUE                       1101
#define IDC_PROMPT                      1102
#define IDC_SYMBOL                      1103
#define IDC_DATASIZE                    1105
#define IDC_EDIT1                       1106
#define IDC_OP                          1106
#define IDC_DEVICE                      1108
#define ID_MAP                          1109
#define IDC_ABORT                       1111
#define ID_SYMBOLS_CLEAR                1112
#define IDC_CLEAR                       1112
#define IDC_BIND                        1114
#define IDC_RUMBLE                      1116
#define IDC_DATA                        1117
#define IDC_TYPE                        1118
#define IDC_ADDRESS                     1119
#define IDC_WATCH                       1120
#define IDC_EDIT                        1121
#define ID_QUIT                         40001
#define ID_LOAD_BIOS                    57616
#define ID_SCREENSHOT                   57617

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        229
#define _APS_NEXT_COMMAND_VALUE         40020
#define _APS_NEXT_CONTROL_VALUE         1123
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
