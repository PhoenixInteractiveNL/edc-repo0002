Minimon 2004-01-19

Bryon Vandiver (asterick@buxx.com)

Please note:  all requests for commercial roms will be prompty ignored.  Do no spam me will stuff like 'It runs too slow!' or anything like that, I work as quickly as I possibly can.  Feature requests are always welcome.

Source provided is a minor modification of the HQ libraries, released under the LGPL licence.

===== Notes about the emulator =====

I've decided to go ahead and start working on this document before it never gets done (otherwise, people like zophar might never link to me...)

Anywho... you absolutely MUST have the BIOS image inorder to play it... some of the homebrew roms have it packaged at the first 8k of the rom (minimon will load those as a bios image), other places like darkfader.net have the actual US bios dump.  Eventually, i plan on just rewritting the bios completely so I can include it with the emulator, but that is a way's off.

There are a couple of notes about this release:

1) Windows 95/98 has problems involving the menu system.  I cannot fix this, it is something to do with the message dispatch of that OS.  I recommend using 2000/XP.
2) The debugger takes a LOT of CPU time... THis is mostly due to overdraw and GDI... I don't plan on converting it to DX either, since it runs at full speed on my PC, and the debugger is basicly useless if you are running fullspeed anyway.

===== Running Minimon =====

First, you must obtain the bios image, minimon will auto-load "bios.min" from it's root directory if you provide it.  After that, load another rom and just run it.

Default Key mapping (changable under the configure menu):

Reset: Tab
Power: Return
A:     C
B:     X
C:     Z
Shake: S
Turbo: ` (next to 1 on the US keyboard)

Static Key Mapping:

Fullspeed Run: F5
Debugspeed Run: Ctrl-F5
Step opcode: Space

Double clicking left (mouse) in the debugger / memory / watch editors will provide you with various debugger like tools.  Most of which are specific to what you are clicking (clicking an address/symbol in the disassembler will branch or create a memory watch, depending, clicking to the immediate left of an op will toggle a break point, etc)

The only exception is the watchpoint viewer, which clicking right will delete a watch point.

Just experiment to figure it all out... there is a lot of functions that I just don't remember off hand!  (As is the problem with putting off writting documentation for so long)

Everything else should be self explanitory.

minimon.cfg is basicly considered as 'do not tamper', but most of it can be toyed with if you are a smartie.  the inputmap core provides a lot more functionality that I use it for, so feel free to play with it if you want... but be fore warned... I won't be held responcible if you break it!

===== Change log =====

---- 2005:01:20 ----
* Moved to a GPL licence policy, due to the fact that I'm running a little low on time.  See site for details on how to submit patches to the primary source tree

---- 2005:01:18 ----
* Moved to JB style timers (sped up significantly though, because they seemed too slow)

---- 2005:01:12 ----
* Forgot that my new host requires HTTP/1.1 requests, fixed that bugger right up.

---- 2005:01:10 ----
* Changed the addresses over to the new host

---- 2004:12:17 ----
* Internalized the bios image (bios.min no longer required)
* Fixed the problem with celebi (CPU was underclocked too far)
* Rumble now occurs (Cart IRQ 9)
* Modified IRQ code to be more intelligent (A little slower though)

---- 2004:12:06 ----
* RTC is now set based of the system clock, and the 'set time' menu does not appear on startup

---- 2004:11:23a ----
* Cleaned up the auto-updater, and added additional code to allow for large change-logs (>2k).
* Fixed a bug in the auto update feature (was displaying the date wrong)

---- 2004:11:23 ----
* Added an auto update feature

---- 2004:11:22 ----
* Minimon now remembers if emulated gray is set.  
* Added New video filters, HQ2X - HQ4X, an interlaced mode (32bpp modes only)  
* Support for non-flickering grey emulation  
* Added a 'throttle' command, new inputmap added  

---- 2004:11:12 ----
* Fixed non-masked 16bpp modes  
* Fixed a bug with the 'enable' / 'disable', caused the developer view to start very small.  
* Added the ability to disable LCD mask filtering  
* Removed Timer 0 IRQ execution (causes Pichu Bros to lock)  
* Added a Emulation speed counter to the title bar (so people with slow computers, <~300mhz can tell how fast the emulator is running.  
* Config now remembers the last rom you loaded (so you can have your roms stored else where), if the debugger was enabled, and the LCD size
* added [-1,-2,-3,-4] to the command line, changes the LCD size on boot (gui disabled only)  
* Rewrote the VPU core... over 2x faster now.  
* Added an IRQ prediction routine that helps reduce load when the virtual CPU is stalled.  
* Added a simple command line interface... minimon.exe [-r] [-d] romname Romname autoloads a rom... -r auto starts the emulator... -d disables the debugger.  
* Moved offscreen frame buffer to system memory, caused a HUGE performance increase on my PC (dropped the LCD blitter from #1 on the optomize list to #5)  

---- 2004:11:08 ----
* Added version revisions w/new title bar.  
* Optomized some (now it's a little more than 100% faster). You can thank intel VTune for that one.  
* Fixed a bug in the gradient tag processing (colors are better now)  
* Added a fill tag to the palette, so people can do JB style palettes (note, it's a 33%:66% blur ratio, not 50:50, so it does not look quite right). The palette in the config shows how to use the new tag, it also provides a much better palette (sharper color)  
* Did some more hacking on the pokemon channel emulator, and discovered that when the U and V registers are not equal, IRQs cannot occur. This appears to have solved the mysterious 'Game crash ahoy'! problem.  
* Changed IRQ functions to a queue system, which presumably is how the actual system works  
* Removed emulation loop audio, since it was underrunning way too often. I don't know if this is a problem with DirectSound, or what, but it turns out that it's way too hard to sync. I moved to a threaded notification system that breaks the audio down into segments. It is a little less accurate, but a lot more reasonable. (Also allows me to filter the audio)  

---- 2004:11:02 ----
* Added support to disable the audio completely  
* Is the emulation buffer underflows, the system with throttle it to catch up. If audio sounds bad, it's because your system can not keep up.  
* Now supports the ability to assemble instructions in place (minimon assembly syntax)  
* Debugger can now alter ROM.  
* Moved waveform generation to be generated by the execution loop. This makes audio output a LOT more accurate and responcive. Also, since audio has to be locked less frequently now (~1/10th the time), it should also release some load from the CPU!  
2004:10:29 Double clicking in next to an opcode now allows users to add a breakpoint  
* Double clicking a branch address left moves the disassembler to that address, double right sets a break point at that address, double clicking on a memory address used opens up the 'edit memory' dialog.  
* Added the ability to jump to ambiguous locations in the disassembler. (Current page only)  
* Moved to floating point frequency conversion. Makes the frequencies more accurate, but the audio can sound staticy at times (especially on high frequencies).  
* Double clicking right deletes a watchpoint in the list  
* Double clicking the memory viewer allows you to change values and set watch points  
* Double clicking a watchpoint now allows you to change it's value  
* You can now save and add symbols  
* Fixed a problem where changing the minx settings prevented the primary window from receving keypresses.  
* Added the ability to delete symbols / breakpoints / watches individually.  

---- 2004:10:25 ----
* Added audio output and timer1 IRQ  
* Fixed 12 bytes of waste on eeproms (not really needed)  
* Added timers 0-2, but I do not know how their IRQs occur, or when they do.  
* Fixed a problem with new eeproms inheriting saves from the last game loaded.  
---- 2004:10:22 ----
* Fixed a minor problem with analog inputs  
* Fixed break on BIOS IRQ  
* The emulator now idles when it is inactive.  
* Fixed the input core to supports most all sliders, and one POV hat. This is 'typical' for most joysticks, more will just slow the emulation down.  
* Added the rumble support core  
* Added support to do specific resizes of the LCD window (non-debug mode)  
* Emulation / Input processing no longer happens if the primary window is inactive  
* Sync no longer 'catches up' if the emulation lags behind  
* The error console no longer automatically pops up, you must open it manually  

---- 2004:10:21 ----
* Fixed a a problem with the packed color creation that caused 16BPP colors to lose their blue values  
* Added a function to disable the debuggers and make the LCD extend the entire window.  

---- 2004:10:20 ----
* Fixed a problem with the LCD code in 16bpp color, was causing the screen to be double wide  
* Fixed a minor problem with EEPROMs not getting saved when you quit the emulator, rather than load a new rom or close the current one.  
* New Palette and Input core in place.  
* Created an XML Configuration system  
* Did quite a bit of internal clean up (more is needed)  
* Made the LCD have a grid mask, so it looks more authentic  
* Moved to DirectDraw for the LCD view, this makes the video a lot cleaner. (24bpp modes not supported, only 32 and 16)  
* Altered EEPROM code to save a eeprom PER rom, rather than just to c:\eeprom.min  
* Added shock IRQ (not maskable by IE... this will eventually change)  
* Fixed a problem with BCD addition (carry at 0x99 not 0x100)  

---- 2004:10:15 ----
* Fixed BCD (was only adding the lower nybble  
* Fixed 16 bit addition (signs were getting clobbered)  
* Fixed prohibited map size, actually 24x16 (see togepi)  
* First version to run everything!  

---- 2004:10:14 ----
* Fixed a major issue with the IRQ code, so the hack has been removed.  
