#ifdef EXPORT
int   LUT16to32[65536];
int   RGBtoYUV[65536];
#else
extern int   LUT16to32[65536];
extern int   RGBtoYUV[65536];
#endif

#pragma warning( disable : 4799 )

void hq2x_32( unsigned char * pIn, unsigned char * pOut, int Xres, int Yres, int BpL );
void hq3x_32( unsigned char * pIn, unsigned char * pOut, int Xres, int Yres, int BpL );
void hq4x_32( unsigned char * pIn, unsigned char * pOut, int Xres, int Yres, int BpL );
void InitLUTs(void);
