This is release 2.7.5 of Stella.  Stella is a multi-platform Atari 2600 VCS
emulator which allows you to play all of your favorite Atari 2600 games
on your PC.  You'll find the Stella Users Manual in the docs subdirectory.
If you'd like to verify that you have the latest release of Stella visit
the Stella Website at:

  http://stella.sourceforge.net

Enjoy,

The Stella Team
March 27, 2009
