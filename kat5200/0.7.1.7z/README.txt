Ensure Visual C++ 2015 Redistributable is installed:
https://www.microsoft.com/en-us/download/details.aspx?id=48145