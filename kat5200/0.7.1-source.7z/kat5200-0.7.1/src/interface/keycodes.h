#ifndef KEYCODES_H
#define KEYCODES_H

/*
 * Takes input SDL1 keycode and converts to SDL2
 */
int key_convert (int key) {

    if (key == 8) return SDLK_BACKSPACE;
    if (key == 9) return SDLK_TAB;
    if (key == 12) return SDLK_CLEAR;
    if (key == 13) return SDLK_RETURN;
    if (key == 19) return SDLK_PAUSE;
    if (key == 27) return SDLK_ESCAPE;
    if (key == 32) return SDLK_SPACE;
    if (key == 33) return SDLK_EXCLAIM;
    if (key == 34) return SDLK_QUOTEDBL;
    if (key == 35) return SDLK_HASH;
    if (key == 36) return SDLK_DOLLAR;
    if (key == 38) return SDLK_AMPERSAND;
    if (key == 39) return SDLK_QUOTE;
    if (key == 40) return SDLK_LEFTPAREN;
    if (key == 41) return SDLK_RIGHTPAREN;
    if (key == 42) return SDLK_ASTERISK;
    if (key == 43) return SDLK_PLUS;
    if (key == 44) return SDLK_COMMA;
    if (key == 45) return SDLK_MINUS;
    if (key == 46) return SDLK_PERIOD;
    if (key == 47) return SDLK_SLASH;
    if (key >= 48 && key <= 57) return SDLK_0 + (key-48);
    if (key == 58) return SDLK_COLON;
    if (key == 59) return SDLK_SEMICOLON;
    if (key == 60) return SDLK_LESS;
    if (key == 61) return SDLK_EQUALS;
    if (key == 62) return SDLK_GREATER;
    if (key == 63) return SDLK_QUESTION;
    if (key == 64) return SDLK_AT;
    if (key == 91) return SDLK_LEFTBRACKET;
    if (key == 92) return SDLK_BACKSLASH;
    if (key == 93) return SDLK_RIGHTBRACKET;
    if (key == 94) return SDLK_CARET;
    if (key == 95) return SDLK_UNDERSCORE;
    if (key == 96) return SDLK_BACKQUOTE;
    if (key >= 97 && key <= 122) return SDLK_a + (key-97);
    if (key == 127) return SDLK_DELETE;
    if (key == 256) return SDLK_KP_0;
    if (key >= 257 && key <= 265) return SDLK_KP_1 + (key-257);
    if (key == 266) return SDLK_KP_PERIOD;
    if (key == 267) return SDLK_KP_DIVIDE;
    if (key == 268) return SDLK_KP_MULTIPLY;
    if (key == 269) return SDLK_KP_MINUS;
    if (key == 270) return SDLK_KP_PLUS;
    if (key == 271) return SDLK_KP_ENTER;
    if (key == 272) return SDLK_KP_EQUALS;
    if (key == 273) return SDLK_UP;
    if (key == 274) return SDLK_DOWN;
    if (key == 275) return SDLK_RIGHT;
    if (key == 276) return SDLK_LEFT;
    if (key == 277) return SDLK_INSERT;
    if (key == 278) return SDLK_HOME;
    if (key == 279) return SDLK_END;
    if (key == 280) return SDLK_PAGEUP;
    if (key == 281) return SDLK_PAGEDOWN;
    if (key >= 282 && key <= 293) return SDLK_F1 + (key-282);
    if (key == 300) return SDLK_NUMLOCKCLEAR;
    if (key == 301) return SDLK_CAPSLOCK;
    if (key == 302) return SDLK_SCROLLLOCK;
    if (key == 303) return SDLK_RSHIFT;
    if (key == 304) return SDLK_LSHIFT;
    if (key == 305) return SDLK_RCTRL;
    if (key == 306) return SDLK_LCTRL;
    if (key == 307) return SDLK_RALT;
    if (key == 308) return SDLK_LALT;
    if (key == 309) return SDLK_RGUI;
    if (key == 310) return SDLK_LGUI;
    if (key == 311) return SDLK_RGUI;
    if (key == 312) return SDLK_LGUI;
    if (key == 313) return SDLK_MODE;
    if (key == 314) return SDLK_APPLICATION;
    if (key == 317) return SDLK_SYSREQ;
    if (key == 318) return SDLK_PAUSE;
    if (key == 319) return SDLK_MENU;
    if (key == 320) return SDLK_POWER;
    if (key == 322) return SDLK_UNDO;

    return key;
}

int key_mod_convert(int key) {

    if (key == 0x0001) return KMOD_LSHIFT;
    if (key == 0x0002) return KMOD_RSHIFT;
    if (key == 0x0040) return KMOD_LCTRL;
    if (key == 0x0080) return KMOD_RCTRL;
    if (key == 0x0100) return KMOD_LALT;
    if (key == 0x0200) return KMOD_RALT;
    if (key == 0x0400) return KMOD_LGUI;
    if (key == 0x0800) return KMOD_RGUI;

    if (key == 0x1000) return KMOD_NUM;
    if (key == 0x2000) return KMOD_CAPS;
    if (key == 0x4000) return KMOD_MODE;

    if (key == (0x0001 | 0x0002)) return KMOD_SHIFT;
    if (key == (0x0040 | 0x0080)) return KMOD_CTRL;
    if (key == (0x0100 | 0x0200)) return KMOD_ALT;
    if (key == (0x0400 | 0x0200)) return KMOD_GUI;

    return key;
}

#endif
