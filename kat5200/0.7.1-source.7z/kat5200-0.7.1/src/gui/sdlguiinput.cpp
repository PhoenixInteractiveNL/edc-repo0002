/******************************************************************************
*
* FILENAME: sdlguiinput.cpp
*
* DESCRIPTION:  My own version of Guichan's SDLInput to handle joysticks
*
* AUTHORS:  bberlin
*
* CHANGE LOG
*
*  VER     DATE     CHANGED BY   DESCRIPTION OF CHANGE
* ------  --------  ----------   ------------------------------------
* 0.5.0   09/20/06  bberlin      Creation
******************************************************************************/
#include "sdlguiinput.hpp"
#include "guichan/exception.hpp"

extern "C" {
	#include "../interface/sdl_if.h"
}

namespace gcn
{
    SDLGuiInput::SDLGuiInput()
    {

    }

    bool SDLGuiInput::isJoystickQueueEmpty()
    {
        return mJoystickInputQueue.empty();
    }

    JoystickInput SDLGuiInput::dequeueJoystickInput()
    {
        JoystickInput joystickInput;

        if (mJoystickInputQueue.empty())
        {
            throw GCN_EXCEPTION("The queue is empty.");
        }

        joystickInput = mJoystickInputQueue.front();
        mJoystickInputQueue.pop();

        return joystickInput;
    }

    void SDLGuiInput::pushInput(SDL_Event event)
    {
        KeyInput keyInput;
        MouseInput mouseInput;
        JoystickInput joystickInput;
        int tmp_joy_index = 0;

        switch (event.type)
        {
          case SDL_JOYBALLMOTION:
              tmp_joy_index = pc_get_joystick_index_from_id(event.jball.which);
			  joystickInput.setDevice(event.jball.which);
			  joystickInput.setType(JoystickInput::BALL);
			  joystickInput.setPart(event.jball.ball);
			  joystickInput.setX(event.jball.xrel);
			  joystickInput.setY(event.jball.yrel);
			  mJoystickInputQueue.push(joystickInput);
              break;
          case SDL_JOYHATMOTION:
              tmp_joy_index = pc_get_joystick_index_from_id(event.jhat.which);
			  joystickInput.setDevice(tmp_joy_index);
			  joystickInput.setType(JoystickInput::HAT);
			  joystickInput.setPart(event.jhat.hat);
			  joystickInput.setValue(event.jhat.value);
			  mJoystickInputQueue.push(joystickInput);
              break;
          case SDL_JOYAXISMOTION:
              tmp_joy_index = pc_get_joystick_index_from_id(event.jaxis.which);
			  joystickInput.setDevice(tmp_joy_index);
			  joystickInput.setType(JoystickInput::AXIS);
			  joystickInput.setPart(event.jaxis.axis);
			  joystickInput.setValue(event.jaxis.value);
			  mJoystickInputQueue.push(joystickInput);
              break;
          case SDL_JOYBUTTONDOWN:
              tmp_joy_index = pc_get_joystick_index_from_id(event.jbutton.which);
			  joystickInput.setDevice(tmp_joy_index);
			  joystickInput.setType(JoystickInput::BUTTON);
			  joystickInput.setPart(event.jbutton.button);
			  joystickInput.setValue(JoystickInput::PRESS);
			  mJoystickInputQueue.push(joystickInput);
              break;
          case SDL_JOYBUTTONUP:
              tmp_joy_index = pc_get_joystick_index_from_id(event.jbutton.which);
			  joystickInput.setDevice(tmp_joy_index);
			  joystickInput.setType(JoystickInput::BUTTON);
			  joystickInput.setPart(event.jbutton.button);
			  joystickInput.setValue(JoystickInput::RELEASE);
			  mJoystickInputQueue.push(joystickInput);
              break;

        } // end switch

		SDLInput::pushInput(event);
    }
}
