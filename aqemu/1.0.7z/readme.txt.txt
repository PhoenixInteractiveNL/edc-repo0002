
                           AqEmu

(c) Copyright 2000 by Kenny Millar

email: AqEmu@classicgaming.com

Thanks for downloading the worlds first Mattel Aquarius Emulator.

I started this emulator as a fun project to keep my C++ Skills up to date.

Make sure that Aquarius.rom is in the same directory as AqEmu.exe
It will only work on Windows 95/98/NT and Windows 2000,
Sorry, but it does not work under DOS, Linux, Beos or Windows 3.x

NOTES.
1. The keyboard emulation faithfully emulates the properties of the old
Aquarius. This includes having some characters in strange places and 
the quirky behaviour where sometimes a keypress is not recognized immediately.

Aquarius veterans will remember having to type slowly!!!!

You can use CTRL along with various keys to speed up typing.
here is a list of all the CTRL key combinations:

CTRL+1	=	RUN
CTRL+2	=	LIST
CTRL+3	=	IF
CTRL+4	=	THEN
CTRL+5	=	GOTO
CTRL+6	=	ON
CTRL+7	=	GOSUB
CTRL+8	=	RETURN
CTRL+9	=	COPY
CTRL+-	=	FOR
CTRL+=	=	NEXT

CTRL+W	=	REM
CTRL+E	=	DIM
CTRL+R	=	RETYP
CTRL+T	=	INPUT
CTRL+A	=	CSAVE
CTRL+S	=	STPLST
CTRL+D	=	READ
CTRL+F	=	DATA
CTRL+G	=	BELL
CTRL+J	=	PSET
CTRL+K	=	PRESET
CTRL+L	=	POINT
CTRL+;	=	POKE
CTRL+:	=	PEEK
CTRL+SPACE	CHR$
CTRL+Z	=	CLOAD
CTRL+X	=	DELINE
CTRL+C	=	STOP
CTRL+V	=	LEFT$
CTRL+B	=	MID$
CTRL+N	=	RIGHT$
CTRL+,	=	STR$
CTRL+.	=	VAL



