
As you may remember, the Aquarius tape file format has no checksums or quality of data checks, so images made from Aquarius tapes may be unreliable.


In Disco Fever, one of the dancers appears to be displaced.

If you have an actual Disco Fever cassette, try making CAQ images from both sides of the tape, and send them along to me for possible inclusion in some future version of the emulator archive.  Thanks.
