Yie Ar Kung Fu music

I learned that you have to wait a bit before attempting to load the array portion.  If it doesn't load the first try, it will load on the second.  I'm used to the other loaders, which accept the array immediately.
