
This is probably not a good image of the cassette software.  My cassette is hosed -- my real Aquarius won't load in the software from the cassette.  Remember, the Aquarius tape file format has no checksums or quality-of-data safeguards.

I am including this probably defective image on the "anything is better than nothing" principle.  Caveat Emptor.

