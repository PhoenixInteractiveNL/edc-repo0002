Turn Word Wrap ON if you're using Notepad.

To use these ROMs, from Virtual Aquarius's file menu, select Load Game ROM.  Select an appropriate cartridge image (.bin file) to load.

To start the software on the cartridge, then select Hard Reset from Virtual Aquarius's file menu.

Note that this is "live" plugging in of the cartridge -- the equivalent of plugging the real cartridge into the real computer while the power is on.

To reiterate:
1.  From the File menu, Load Game ROM.
2.  From the File menu, Hard Reset.


======
radofin.bin is the S2 BASIC ROM image for the Aquarius computer.

AD&D.bin
	dumped by P. - matches my dump and SP.'s

astrosmash.bin
	dumped by me

biorhythms.bin
	dumped by me

BurgerTime.bin
	dumped by P.

chess.bin
	dumped by don't remember
	possibly hacked

ExtendedBasic.bin
	dumped by me

fileform.bin
	dumped by me

finform.bin
	dumped by me

logo.bin
	dumped by me
	This appears to be defective.

MarqueeDemo.bin
	dumped by P.

MelodyChase.bin
	dumped by P.

nightstalker.bin
	dumped by me

QuickDisk.bin
	dumped by P.

radofin.bin
	dumped by me

S_Burgertime.rom
	Obtained from SP.  Hacked version of Burgertime.

S_ExtendedBasic.rom
	Obtained from SP.  Extended BASIC.  Hacked.
	Note:  It's a 4K cart, and the image appears twice in the dump --
	if the hacked portions are replaced with the corresponding
	other image portions, then it matches the dump made by me

S_ModemTerminalSoftware.rom
	Obtained from SP.  Hacked?

S_WordProcessor.rom
	Obtained from SP.  Appears to be hacked version of Fileform.

Shark!.bin
	dumped by P.

snafu.bin
	dumped by me

SpaceSpeller.bin
	dumped by P.

TronDeadlyDiscs.bin
	dumped by me

utopia.bin
	dumped by me

Zeroin.bin
Zeroinm.bin
	dumped by ? -- obtained from M.  Hacked?

