#ifndef _DJGPP_INCLUDE_EDIT_RAM
#define _DJGPP_INCLUDE_EDIT_RAM

#include "pce.h"
/*
#include "svgaallg.h"
*/
#include "debug.h"

void edit_ram();
// the main function to edit ram

#endif
