void eagle
    ( 	unsigned long *lb,
		unsigned long *lb2,
		short width,
		int destination_segment,
		int screen_address1,
		int screen_address2 )
      {
       }

void _eagle
    ( 	unsigned long *lb,
		unsigned long *lb2,
		short width,
		int destination_segment,
		int screen_address1,
		int screen_address2 )
      {
       }
