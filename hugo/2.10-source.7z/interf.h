#ifndef _DJGPP_INCLUDE_INTERF_H
#define _DJGPP_INCLUDE_INTERF_H

/*
#include "svgaallg.h"
*/
#include "pce.h"
#include <math.h>

UChar gui();
// This function calls a true GUI allowing to change options, etc...

extern char skin_filename[256];
// filename of the skin to use

#endif
