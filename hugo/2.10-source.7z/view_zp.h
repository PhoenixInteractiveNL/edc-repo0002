#ifndef _DJGPP_INCLUDE_VIEW_ZP
#define _DJGPP_INCLUDE_VIEW_ZP

#include "pce.h"
/*
#include "svgaallg.h"
*/
#include "debug.h"

void view_zp();
// the main function to edit ram

#endif
