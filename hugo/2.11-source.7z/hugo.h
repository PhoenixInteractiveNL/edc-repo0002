#ifndef _INCLUDE_HUGO_H
#define _INCLUDE_HUGO_H

#include "pce.h"
#include "iniconfig.h"
#ifdef GTK
#include "gtk_main.h"
#endif

#endif
