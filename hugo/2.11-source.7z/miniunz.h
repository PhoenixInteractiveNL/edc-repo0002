#ifndef MINIUNZ_H
#define MINIUNZ_H

char *find_possible_filename_in_zip (char *zipfilename);
int extractFile (char *zipfilename, char *archivedfile);


#endif
