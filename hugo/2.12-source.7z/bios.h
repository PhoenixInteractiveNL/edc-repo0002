#ifndef INCLUDE_BIOS_H
#define INCLUDE_BIOS_H

void handle_bios(void);
/* Perform the bios hooking function */

#endif
