#ifndef INCLUDE_BP_H
#define INCLUDE_BP_H

int handle_bp0();
int handle_bp1();
int handle_bp2();
int handle_bp3();
int handle_bp4();
int handle_bp5();
int handle_bp6();
int handle_bp7();
int handle_bp8();
int handle_bp9();
int handle_bp10();
int handle_bp11();
int handle_bp12();
int handle_bp13();
int handle_bp14();
int handle_bp15();

#endif
