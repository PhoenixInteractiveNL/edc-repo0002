#ifndef _INCLUDE_OSD_H
#define _INCLUDE_OSD_H

#include "cleantyp.h"
// #include <windows.h>
#include "pce.h"
#include <stdio.h>
#include <string.h>

#if defined(ALLEGRO)

#include "myaspi32.h"
#include <allegro.h>
#include <winalleg.h>

#endif

#endif

