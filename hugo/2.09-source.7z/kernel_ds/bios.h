#ifndef INCLUDE_BIOS_H
#define INCLUDE_BIOS_H

int
handle_bios();
/* Perform the bios hooking function */

#endif
