#ifndef _INCLUDE_LINUX_OSD_GFX_H
#define _INCLUDE_LINUX_OSD_GFX_H

#include "cleantyp.h"
#include "pce.h"
#include "sys_dep.h"

extern int blit_x,blit_y;
// where must we blit the screen buffer on screen

extern int screen_blit_x, screen_blit_y;
// where on the screen we must blit XBuf


#endif
