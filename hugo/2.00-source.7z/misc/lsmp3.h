#ifndef _DJGPP_INCLUDE_LSMP3_H
#define _DJGPP_INCLUDE_LSMP3_H

float MP3_length(char *);

#endif
