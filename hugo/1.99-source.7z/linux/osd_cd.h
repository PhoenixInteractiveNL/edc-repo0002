#ifndef _INCLUDE_LINUX_OSD_CD_H
#define _INCLUDE_LINUX_OSD_CD_H

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <linux/cdrom.h>
#include <sys/ioctl.h>

#include "sys_dep.h"
#include "cd.h"


#endif
