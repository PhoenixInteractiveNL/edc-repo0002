/* Allegro data file definitions, produced by dat2s v3.11 */
/* Input file: hu-go!.dat */
/* Date: Wed Sep 15 09:54:31 1999 */
/* Do not hand edit! */

extern unsigned char built_in_cdsystem[];
extern BITMAP fileselector_bg;
extern PALETTE fileselector_pal;
extern PALETTE intro_pal;
extern BITMAP intro_picture;
extern DATAFILE data[];
