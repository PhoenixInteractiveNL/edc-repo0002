/* Allegro datafile object indexes, produced by grabber v3.11 */
/* Datafile: c:\prog\hu-go!\hu-go!.dat */
/* Date: Sat Sep  4 02:31:23 1999 */
/* Do not hand edit! */

#define Built_in_cdsystem                0        /* PCE  */
#define FILESELECTOR_BG                  1        /* BMP  */
#define FILESELECTOR_PAL                 2        /* PAL  */
#define INTRO_PAL                        3        /* PAL  */
#define INTRO_PICTURE                    4        /* BMP  */

