#ifndef _INCLUDE_GENERIC_OSD_CD_H
#define _INCLUDE_GENERIC_OSD_CD_H

#include "sys_dep.h"
#include "cd.h"


#endif
