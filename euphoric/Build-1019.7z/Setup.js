// This script installs shortcut in Windows Program Menu
// and registry keys so that Euphoric can be launched by double-clicking
// tape or disk images.


Shell = WScript.CreateObject("WScript.Shell");
FullName = WScript.ScriptFullName;
EuphoricPath = FullName.substr(0, FullName.length-WScript.ScriptName.length);

fso = new ActiveXObject("Scripting.FileSystemObject");
MenuPath = Shell.SpecialFolders("Programs")+"\\Euphoric";     
if ( ! fso.FolderExists(MenuPath) )
	fso.CreateFolder(MenuPath);     

// Cr�ation du raccourci Atmos
link = Shell.CreateShortcut(MenuPath + "\\Configuratoric.lnk");
link.Description = "Configuratoric";
link.TargetPath = EuphoricPath + "configuratoric.exe";
link.WorkingDirectory = EuphoricPath;
link.Save();

// Cr�ation du raccourci Atmos
link = Shell.CreateShortcut(MenuPath + "\\Atmos.lnk");
link.Description = "Atmos";
link.IconLocation = EuphoricPath + "icons\\atmos.ico";
link.TargetPath = EuphoricPath + "euphoric.exe";
link.WindowStyle = 3;
link.WorkingDirectory = EuphoricPath;
link.Save();

// Cr�ation du raccourci Atmos+Microdisc
link = Shell.CreateShortcut(MenuPath + "\\Atmos+Microdisc.lnk");
link.Arguments = "-d";
link.Description = "Atmos+Microdisc";
link.IconLocation = EuphoricPath + "icons\\microdisc.ico";
link.TargetPath = EuphoricPath + "euphoric.exe";
link.WindowStyle = 3;
link.WorkingDirectory = EuphoricPath;
link.Save();

// Cr�ation du raccourci Atmos+Jasmin
link = Shell.CreateShortcut(MenuPath + "\\Atmos+Jasmin.lnk");
link.Arguments = "-j";
link.Description = "Atmos+Jasmin";
link.IconLocation = EuphoricPath + "icons\\jasmin.ico";
link.TargetPath = EuphoricPath + "euphoric.exe";
link.WindowStyle = 3;
link.WorkingDirectory = EuphoricPath;
link.Save();

// Cr�ation du raccourci Atmos+BD500
link = Shell.CreateShortcut(MenuPath + "\\Atmos+BD500.lnk");
link.Arguments = "-b";
link.Description = "Atmos+BD500";
link.IconLocation = EuphoricPath + "icons\\bd500.ico";
link.TargetPath = EuphoricPath + "euphoric.exe";
link.WindowStyle = 3;
link.WorkingDirectory = EuphoricPath;
link.Save();

// Cr�ation du raccourci Telestrat
link = Shell.CreateShortcut(MenuPath + "\\Telestrat.lnk");
link.Arguments = "-t";
link.Description = "Telestrat";
link.IconLocation = EuphoricPath + "icons\\telestrat.ico";
link.TargetPath = EuphoricPath + "euphoric.exe";
link.WindowStyle = 3;
link.WorkingDirectory = EuphoricPath;
link.Save();

// Cr�ation du raccourci Oric1
link = Shell.CreateShortcut(MenuPath + "\\Oric1.lnk");
link.Arguments = "-1";
link.Description = "Oric-1";
link.IconLocation = EuphoricPath + "icons\\oric1.ico";
link.TargetPath = EuphoricPath + "euphoric.exe";
link.WindowStyle = 3;
link.WorkingDirectory = EuphoricPath;
link.Save();


// Cr�ation du raccourci Pravetz
link = Shell.CreateShortcut(MenuPath + "\\Pravetz.lnk");
link.Arguments = "-p";
link.Description = "Pravetz";
link.IconLocation = EuphoricPath + "icons\\pravetz8D.ico";
link.TargetPath = EuphoricPath + "euphoric.exe";
link.WindowStyle = 3;
link.WorkingDirectory = EuphoricPath;
link.Save();

// Cr�ation du raccourci Pravetz+Disk
link = Shell.CreateShortcut(MenuPath + "\\Pravetz+DiskII.lnk");
link.Arguments = "-p -d";
link.Description = "Pravetz+DiskII";
link.IconLocation = EuphoricPath + "icons\\NIB-8D.ico";
link.TargetPath = EuphoricPath + "euphoric.exe";
link.WindowStyle = 3;
link.WorkingDirectory = EuphoricPath;
link.Save();


// Cr�ation du raccourci Euphoric.ini
link = Shell.CreateShortcut(MenuPath + "\\Configuration.lnk");
link.Arguments = "-1";
link.Description = "Euphoric.ini";
link.TargetPath = EuphoricPath + "euphoric.ini";
link.WindowStyle = 3;
link.Save();

key =  "HKEY_CLASSES_ROOT\\"
Shell.RegWrite( key + "Applications\\euphoric.exe\\shell\\open\\command\\", "\""+EuphoricPath+"euphoric.exe\" \"%1\"");
Shell.RegWrite( key + ".dsk\\", "Euphoric.Disk");
Shell.RegWrite( key + ".nib\\", "Euphoric.DiskII");
Shell.RegWrite( key + ".tap\\", "Euphoric.Tape");
Shell.RegWrite( key + ".rom\\", "Euphoric.ROM");

// Association des icones
Shell.RegWrite( key + "Euphoric.Tape\\", "Euphoric Tape");
Shell.RegWrite( key + "Euphoric.Tape\\DefaultIcon\\", EuphoricPath+"icons\\tap.ico");
Shell.RegWrite( key + "Euphoric.Disk\\", "Euphoric Disk");
Shell.RegWrite( key + "Euphoric.Disk\\DefaultIcon\\", EuphoricPath+"icons\\dsk.ico");
Shell.RegWrite( key + "Euphoric.DiskII\\", "Euphoric DiskII");
Shell.RegWrite( key + "Euphoric.DiskII\\DefaultIcon\\", EuphoricPath+"icons\\NIB-8D.ico");
Shell.RegWrite( key + "Euphoric.ROM\\", "Euphoric ROM");
Shell.RegWrite( key + "Euphoric.ROM\\DefaultIcon\\", EuphoricPath+"icons\\rom.ico");

// Cr�ation du menu shell .dsk
Shell.RegWrite( key + "Euphoric.Disk\\shell\\", "disc" );
Shell.RegWrite( key + "Euphoric.Disk\\shell\\disc\\", "Boot Microdisc");
Shell.RegWrite( key + "Euphoric.Disk\\shell\\disc\\command\\", "\""+EuphoricPath+"euphoric\" -d \"%1\"");
Shell.RegWrite( key + "Euphoric.Disk\\shell\\jasmin\\", "Start Jasmin");
Shell.RegWrite( key + "Euphoric.Disk\\shell\\jasmin\\command\\", "\""+EuphoricPath+"euphoric\" -j \"%1\"");
Shell.RegWrite( key + "Euphoric.Disk\\shell\\telestrat\\", "Boot Telestrat");
Shell.RegWrite( key + "Euphoric.Disk\\shell\\telestrat\\command\\", "\""+EuphoricPath+"euphoric\" -t \"%1\"");

// Cr�ation du menu shell .nib
Shell.RegWrite( key + "Euphoric.DiskII\\shell\\", "diskII" );
Shell.RegWrite( key + "Euphoric.DiskII\\shell\\diskII\\", "Boot Pravetz");
Shell.RegWrite( key + "Euphoric.DiskII\\shell\\diskII\\command\\", "\""+EuphoricPath+"euphoric\" -p -d \"%1\"");

// Cr�ation du menu shell .tap

Shell.RegWrite( key + "Euphoric.Tape\\shell\\", "atmos" );
Shell.RegWrite( key + "Euphoric.Tape\\shell\\atmos\\", "CLOAD on Atmos");
Shell.RegWrite( key + "Euphoric.Tape\\shell\\atmos\\command\\", "\""+EuphoricPath+"euphoric\" \"%1\"");
Shell.RegWrite( key + "Euphoric.Tape\\shell\\oric1\\", "CLOAD on Oric1");
Shell.RegWrite( key + "Euphoric.Tape\\shell\\oric1\\command\\", "\""+EuphoricPath+"euphoric\" -1 \"%1\"");

// Ajout d'un lecteur .Wav
Shell.RegWrite( key + "SoundRec\\shell\\euphoric\\", "CLOAD on Euphoric");
Shell.RegWrite( key + "SoundRec\\shell\\euphoric\\command\\", "\""+EuphoricPath+"euphoric.exe\" \"%1\"");


// Lancement de Configuratoric
Shell.Run("Configuratoric",1,true);
