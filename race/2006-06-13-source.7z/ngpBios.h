//---------------------------------------------------------------------------
//	This program is free software; you can redistribute it and/or modify
//	it under the terms of the GNU General Public License as published by
//	the Free Software Foundation; either version 2 of the License, or
//	(at your option) any later version. See also the license.txt file for
//	additional informations.
//---------------------------------------------------------------------------

// ngpBios.h: interface for the ngpBios class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NGPBIOS_H__96457662_3A01_11D4_8645_0050DA4EEEA0__INCLUDED_)
#define AFX_NGPBIOS_H__96457662_3A01_11D4_8645_0050DA4EEEA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

void ngpBiosSYSFONTSET(unsigned char *pt, char i, char j);

#endif // !defined(AFX_NGPBIOS_H__96457662_3A01_11D4_8645_0050DA4EEEA0__INCLUDED_)
