Pom1 is an Apple 1 emulator being ported to C from the original Java 
version. It uses the Simple DirectMedia Layer library and works on most 
platforms.

== Options ==

Pom1 has many options to configure and utilize the emulator. They are 
accessed by Ctrl+<letter>.

Option         Letter    Description
-----------------------------------------------------------------
Load Memory    L         Load memory from a binary or ascii file.
Save Memory    S         Save memory to a binary or ascii file.
Quit           Q         Quit the emulator.
Reset          R         Reset the emulator.
Hard Reset     H         Hard reset the emulator.
Pixel Size     P         Set the pixel size (1 or 2).
Scanlines      N         Turn scanlines on or off (pixel size 2 only).
Terminal Speed T         Set the terminal speed.
RAM 8K         E         Use only 8KB of RAM or entire 64KB of RAM.
Write In ROM   W         Allow writing data in ROM or not.
IRQ/BRK Vector V         Set address of interrupt vector.
Full Screen    F         Switch to fullscreen or window.

== Other information ==

 * You can find more information about the project at the Pom1 website:

   http://pom1.sourceforge.net/