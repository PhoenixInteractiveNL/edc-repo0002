#!/bin/sh

aclocal
automake -a -c
autoconf
automake

./configure $@

