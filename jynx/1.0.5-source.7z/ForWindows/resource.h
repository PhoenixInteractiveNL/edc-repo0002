//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Jynx.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CamputersLynxEmTYPE         130
#define IDD_MAINFORM                    310
#define IDB_BITMAP1                     311
#define IDB_BITMAP_LYNX_PAW             311
#define IDC_EDIT_BLOG                   1000
#define IDC_EDIT_BLOG2                  1001
#define IDC_EDIT_GITHUB                 1001
#define ID_FILE_RUNTAPFILE              32800
#define ID_FILE_OPENTAPFILE             32801
#define ID_FILE_REWINDTAPE              32802
#define ID_FILE_DIRECTORY               32803
#define ID_FILE_INSERTBLANKTAPE         32804
#define ID_FILE_SAVETAPE                32805
#define ID_FILE_LOADSTATESNAPSHOT       32806
#define ID_FILE_SAVESTATESNAPSHOT       32807
#define ID_FILE_EXIT                    32808
#define ID_EMULATION_PAUSE              32820
#define ID_EMULATION_RESET              32821
#define ID_EMULATION_LYNX48K            32822
#define ID_EMULATION_LYNX96K            32823
#define ID_EMULATION_PAUSEAFTERTAPLOAD  32824
#define ID_SPEED_SPEED50                32840
#define ID_SPEED_SPEED100               32841
#define ID_SPEED_SPEED200               32842
#define ID_SPEED_SPEED400               32843
#define ID_SPEED_SPEED800               32844
#define ID_SPEED_MAXSPEEDCASSETTE       32845
#define ID_SPEED_MAXSPEEDCONSOLE        32846
#define ID_SPEED_MAXSPEEDALWAYS         32847
#define ID_DISPLAY_FITTOWINDOW          32860
#define ID_DISPLAY_SQUAREPIXELS         32861
#define ID_DISPLAY_FILLWINDOW           32862
#define ID_DISPLAY_FULLSCREENENABLE     32863
#define ID_SOUND_RECORDTOFILE           32880
#define ID_SOUND_FINISHRECORDING        32881
#define ID_SOUND_LISTENTOTAPESOUNDS     32882
#define ID_SOUND_ENABLE                 32883
#define ID_TEXT_RECORDLYNXTEXT          32900
#define ID_TEXT_STOPRECORDINGLYNXTEXT   32901
#define ID_TEXT_TYPEINFROMFILE          32902
#define ID_TEXT_LYNXBASICREMCOMMANDEXTENSIONS 32903
#define ID_HELP_ABOUT                   32920

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32921
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
