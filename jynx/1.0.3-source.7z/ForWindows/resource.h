//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Jynx.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_CamputersLynxEmTYPE         130
#define IDD_MAINFORM                    310
#define IDB_BITMAP1                     311
#define IDB_BITMAP_LYNX_PAW             311
#define IDC_EDIT_BLOG                   1000
#define IDC_EDIT_BLOG2                  1001
#define IDC_EDIT_GITHUB                 1001
#define ID_FILE_LOADSTATESNAPSHOT       32771
#define ID_FILE_SAVESTATESNAPSHOT       32772
#define ID_EMULATION_LYNX48K            32773
#define ID_EMULATION_LYNX96K            32774
#define ID_DISPLAY_FITTOWINDOW          32775
#define ID_DISPLAY_SQUAREPIXELS         32776
#define ID_EMULATION_RESET              32777
#define ID_EMULATION_SPEED100           32778
#define ID_EMULATION_SPEED200           32779
#define ID_EMULATION_SPEED400           32780
#define ID_EMULATION_SPEED800           32781
#define ID_EMULATION_SPEED50            32782
#define ID_FILE_INSERTBLANKTAPE         32785
#define ID_FILE_SAVETAPE                32786
#define ID_FILE_REWINDTAPE              32788
#define ID_FILE_OPENTAPFILE             32790
#define ID_HELP_ABOUT                   32791
#define ID_FILE_EXIT                    32792
#define ID_SOUND_LISTENTOTAPESOUNDS     32793
#define ID_SOUND_RECORDTOFILE           32794
#define ID_SOUND_FINISHRECORDING        32795
#define ID_TEXT_RECORDLYNXTEXT          32796
#define ID_TEXT_STOPRECORDINGLYNXTEXT   32798
#define ID_TEXT_LYNXBASICREMCOMMANDEXTENSIONS 32799
#define ID_SOUND_ENABLE                 32800
#define ID_TEXT_TYPEINFROMFILE          32801
#define ID_DISPLAY_FILLWINDOW           32802

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32803
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
