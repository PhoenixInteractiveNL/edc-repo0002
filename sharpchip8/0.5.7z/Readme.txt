SharpChip-8

A propos
--------
SharpChip-8 est un �mulateur du langage interpr�t� Chip-8. C'est un �mulateur encore exp�rimental, gardez donc � l'esprit
que certaines fonctionnalit� ne sont pas encore impl�ment�es.

Configuration requise
---------------------
Processeur 1 Ghz
Carte graphique g�rant OpenGL 1.2
256 Mo de ram
.Net Framework Client Profile 4.0
Windows Vista ou 7 (x86 ou x64)
Windows XP pose certains probl�me avec le .Net Framework 4, cela sera r�gl� quand je proposerais le frontend GTK# qui lui fonctionnera sur tous les syst�mes. En attendant vous pouvez compiler le lib SharpChip8 sous .Net 3.5 et faire de m�me avec le frontend winform.

Historique
----------
19/11/2011: alpha 0.5 codename "Rocks"
- [Nouveau] D�boggeur avec visualisation en temps r�el de tout les informations CPU, Clavier, Ecran
- [Nouveau] Visualiseur et Dumper de m�moire (format .bin et .txt)
- [Nouveau] D�sassembleur avec enregistrement au format .chp et .txt
- [Nouveau] D�but d'impl�mentation d'un Pad virtuel
- [Nouveau] un tas de r�glages sont maintenant disponibles (taille de l'�cran, vitesse d'�mulation, couleurs, son, etc...)
- CPU : Des corrections � l'interpr�tation des Opcodes, cela fixe certains probl�mes et permet � certaines d�mos et certains jeux de fonctionner
- G�n�ral : Un tas de petites correction et surtout, correction du timer de son (le son est jou� normalement maintenant)

5/11/2011 : alpha 0.4a codename "Cold"
- SharpChip8 est maintenant une biblioth�que de classe (SharpChip8.dll) qui est ind�pendante de la partie frontend. Vous pouvez d'ailleurs l'utiliser pour cr�er votre propre �mulateur Chip8 :) (elle a encore besoin de refactoring). Cette s�paration va permettre de r�aliser de multiples frontend, dont celui en GTK# pour Linux & MacOSX
- SharpChip8-wf est le frontend Winform pour Windows
- Les touches F1, F2 et F3 permettent de changer les couleurs d'affichage (c'est inutile mais amusant).
- Le pav� num�rique est utilis� pour les touches 0 � 9 et les touches A, Z, E, Q, S, D correspondent respectivement � A, B, C, D, E, F. Il manque 1 opcode donc �a ne fonctionne pas encore partout, mais on peut tirer (avec la touche 5) dans le jeu UFO.

4/11/2011 : alpha 0.3 codename "Black & White"
- Support du son
- Possibilit� de lancer plusieurs d�mos et jeux
- Utilisation par defaut du .Net Framework Client Profile 4.0

Deux autres alpha ont vues le jour mais elles ce n'�tait que des "test", l'aventure commence vraiment � partir de la 0.3.

Remerciements
-------------
Je remercie mon fr�re Maxime pour avoir r�alis� l'icone et quelques aspects graphique de l'�mulateur (http://arachnospring.blogspot.com/)
Un autre grand merci � BestCoder pour son super tutoriel sur le Chip8.

Contact
-------
Site du projet : http://sharpchip8.codeplex.com
Retrouvez moi sur Twitter : https://twitter.com/#!/cyannick
Retrouvez moi sur Google+ : https://plus.google.com/u/0/114532615363095107351/posts

Yannick Comte 2011 (aka Demonixis)