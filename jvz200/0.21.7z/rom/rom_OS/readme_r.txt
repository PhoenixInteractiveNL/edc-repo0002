Turn Word Wrap ON if you're using Notepad.


======

Vzrom12.bin is the BASIC ROM image for the NTSC VZ200 computer.  JVZ200 contains a copy of this built-in.

VZROM_V20.bin is a BASIC ROM image downloaded from the Internet.  I don't know who dumped it, or whether or not it's byte accurate to any actual ROM.  Caveat emptor.

VZROM_V21.bin is a BASIC ROM image downloaded from the Internet.  It is a 2.0 ROM that has been hacked, but don't ask me how.  Caveat emptor.


