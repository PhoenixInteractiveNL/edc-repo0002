Turn Word Wrap ON if you're using Notepad.

James's VZ200 (hereinafter also called "JVZ200") for Windows95/98, by James the Animal Tamer.  It is not called "Virtual VZ200" because there were three pre-existing emulators for the VZ200.


HOME PAGE:
==========
www.geocities.com/emucompboy
Home of the Virtual Aquarius

CONTACT:
========
emucompboy@yahoo.com


NOTE to ROM IMAGE COLLECTORS:
=============================
Okay, this is a change from my previous policy, so read it!
1.  It's okay to put the emulator archive up for download on your website.  If you do put it up, I ask that you include on your website a link to James the Animal Tamer's Emulators (www.geocities.com/emucompboy), as this emulator's home page.  The emulators are works in progress, and I will randomly be updating them, and not necessarily notifying you about it.
2.  You may not charge money for my work.
3.  You may not include any of my emulators or any of my content on any collection or compilation for which you intend to charge money (unless you plan on sending some money to me, Microsoft, Tandy, Panasonic, and any other relevant copyright or license holders).
4.  I'd prefer that you do not unbundle software or other files that are contained within one of my emulator archives (what good are those files without the emulator?  Duh).  That said, I'd be pleased if you make enhanced variants of the computer software and offer those up on your own site.
5.  Oh, please don't link directly to the file names on my site.  I change them with each upate!
Thanks.


System Requirements:
====================
Fast system, Celeron 400MHz or equivalent recommended
Windows95/98
DirectX
16-bit video card (James's VZ200 will work in other modes, but may be slow or not look right)
Sound card compatible with DirectX


Known Bugs
==========
1.  You must configure the printer filename before trying to LPRINT or LLIST or COPY.
2.  CLOAD is far more finicky about the WAVs it will load than a real VZ200.
3.  It won't run CIRCUS.VZ.  (I need to test the image with my real VZ computer some day).
4.  There's another game it doesn't work with, due to that game doing something which resembles saving to cassette, and the emulator auto-detects that and puts up the savefile box.

Preliminary Note:
=================
Here's James's VZ200 version 0.21.  The low number indicates that it's working but missing some features/conveniences.

An important feature for BASIC programmers is Quicktype (from the file menu).  This automatically types a text file.  The best way to use this is to edit a BASIC program as a text file using NOTEPAD.  Save it (from NOTEPAD).  Then use Quicktype to load it into  JVZ200.  This is much easier than trying to type in a program on JVZ200 itself (although that can be done -- beware, the suckiness of the original VZ200 keyboard is emulated in JVZ200).

If you prefer to use the JVZ200's keyboard anyway, you can LLIST your program, then use NOTEPAD to extract your program from the printer output file.  Save out the extracted program to another text file, and you can use the Quicktype feature to load that in.

CSAVE works, for CVZ and WAV files.  Do not try to save a TPD file.  You won't be able to load it back in.

Please note that Quicktype works only with strictly ASCII single keystrokes;  it will not work with graphics characters or inverse.


What works:
=====================
CPU
Memory (with configuration)
Keyboard (emulated and sensible;  can be configured)
Video (Colors can be configured)
Quicktype (provides a means of loading in BASIC programs from text files  -- works with ASCII characters and uppercase only, not the graphics or inverse characters)
LPRINT/LLIST/COPY (To file.  Note that COPY isn't useful -- SORRY! -- use Windows to Printscreen instead.)
BASIC CLOAD (partial support for WAV files, 8-bit mono Microsoft/Creative format, will try to work with any speed, but recommended speed for best results is 44,100 samples per second)
BASIC CSAVE (WAV and CVZ files only -- ignore other options)
Character set (good but not perfect)
Insertion/removal of game cartridges (you need to Hard Reset to start the cartridge)
Video border 
Accurate timing (NTSC is close enough, or configure your own)
Optional loading of other ROM OS
Sound (mostly working)
Window size configuration
Joystick
BASIC CLOAD (CVZ files and WAV files)
BASIC CSAVE (CVZ files and WAV files)
Utility save for .VZ
Utility load for binary
Paste

What does NOT work:
=====================
Timers (if any)
Interrupts (other than VBlank, if any)
Disk Drive
Other peripherals
I/O ports
Banked memory (hey, it's James's VZ200, not James's VZ300!)

What will NEVER work:
=====================
Modem or other RS-232c interface
Any peripheral I can't analyze
Pokemon (sorry, that's for the GAME BOY)


Still left to be done:
======================
CSAVE/CLOAD TPD files
Drag and drop of supported file types (don't hold your breath)
Joystick config
Set default configuration to the right stuff
Utility loaders for Intel Hex, Motorola S
Remove more Virtual Aquarius/Virtual NEC Trek legacy code
Double check the colors for graphics modes
Find out about the hardware hack for other graphics modes and install it as an option



NOTES:
=====================
0.  Many things are not implemented or only partially implemented in this early version.  I/O ports, for example, has a lot of legacy code from the Virtual Aquarius that I have not removed.  

1.  Joysticks.  JVZ200 uses DirectX for joystick input.  JVZ200 is tuned for using "joypads" with two buttons.  The joypads I'm using are Microsoft Sidewinder Game Pads.
	New with 0.21, JVZ200 will also read the first POV hat, if present, so it will work with newer joypads (tested with Logitech Dual Action (USB)).

2.  Sound.  Uses DirectSound.  It is mostly working.  Known problems include:  The Directsound and CPU emulation are not perfectly in sync, so there can be static or an odd echo effect.  At higher frequencies, there is an unpleasant quantization artifacting.  (The 60Hz buzz you hear at all frequencies happens on the real computer unless interrupts are disabled).  Note that if your computer is not running the emulator at a fairly steady 100%, then the sound won't be right and may have problems.  The sound can be VERY LOUD;  in the Sound Configuration box, the default is 50%.  I recommend you don't make it any louder (I am not responsible for damage to your speakers in any case).

3.  Keyboard.  The keyboard operates in one of two modes:  Emulated or Sensible.  Emulated mode is most like the real VZ200 keyboard;  use this mode for playing games.  Sensible makes it easier to type from the PC keyboard.  You can switch back and forth in the same session.  Some games use the CTRL key for input.  To play those games, the keyboard MUST be set to Emulated mode.

4.  CLOAD.  This supports CVZ files, and has partial support for WAV files.  "Partial" in this case means 8-bit mono Microsoft/Creative .WAV format.  Also, the WAV file must be very clean (noise free), and with no "wow/flutter."  I have successfully loaded in files that were digitized from my real NTSC VZ200's CSAVE.  Unfortunately I have not been able to load ANY commercial software this way (my real VZ200 can load only 50% of those, so I'm thinking that there's too much static and "wow/flutter" on those cassettes).
To CLOAD a file from BASIC, first type CLOAD and press the ENTER key.  Then select Play Cassette File from the File menu.  Choose your file type (WAV or CVZ), and choose your cassette file.

5.  Game cartridges.  To use these ROMs, from JVZ200's file menu, select Load Game ROM.  Select an appropriate cartridge image (binary  file, 16384 bytes long) to load.  To start the software on the cartridge, then select Hard Reset from JVZ200's file menu.  This works with the DOS ROM that's floating around the Internet.


Versions:
=========
March 2005: 0.21
	Bundling more software grabbed from other websites (the website http://vzalive.bangrocks.com is THE BIG site for .vz files and VZ-related material).
	Splitscreen!  Matches my NTSC computer.  PAL is guesswork -- that AVI that's floating around the internet just doesn't convey enough info for accuracy.
	Paste.  Quicktypes ASCII text from the clipboard.  See the UTIL menu.
	Quicktype now delays after hitting an ENTER, to allow tokenization.  This may need further adjustment.
	Fixed joystick bug in which "arm" button was pressed all the time!
	Joystick now supports first POV hat, used by modern USB joypads (for you programmer types, that means it'll preferentially use js.lX and js.lY, but if those aren't being used, it'll check js.rgdwPOV[0] if there is a POV hat).
	More removal of fossil code (can't get to the non-existent AY-3-8910 chip any more, LOL)
	Added Util Save RAM as .VZ.
	Added Util Save BASIC program as .VZ.
	Added some code to match advances in VMC10 0.69c.  These include:
	Full screen (press F12 to toggle)
	Screenshot (press F11)
	Redid the sound.  Less likely to hit the unsynchronized static.  The waveform is faked, not that you'd notice, because the VZ200's speaker isn't hi-fi anyway.
	Hooked up F9 hotkey to soft reset.
	Hooked up Shift F9 as hard reset.
	Change in timing to support the changed sound
	Smarter about remembering recent files loaded
	Added Util Load Binary.  Very useful for new software development.  Ha ha.
	Re-enabled ability to load other 768-byte (64 characters * 12 bytes/character) chargen ROMs, and bundled a few examples.  The .FNT/.CHR chargen files used by other emulators are mirror-images, so JVZ200 won't do anything useful with them (try it anyway, go ahead, I dare ya).

March 22, 2002:  0.2
	CSAVEs and CLOADs .CVZ files.
	Considerable amount of code clean-up, removing fossil MC-10 stuff.

February 27, 2002: 0.11
	CSAVEs WAV files.  It's set to use 22050 samples per second, out of deference to the pre-existing emulators and tools.

February 17, 2002: 0.1
	First working version, including Quicktype, keyboard, memory, printer, proper speed, sound, limited support for loading .WAV files, etc. etc. etc.  Not bad for a two day conversion from Virtual Aquarius and Virtual NEC Trek!


Credits
=======
Me (James the Animal Tamer) -- Everything that's not mentioned separately below

Z80Em:		Portable Z80 emulator Copyright (C) Marcel de Kogel 1996,1997
	(I grabbed this from MAME)

ay8910.c	From MAME, credited to Ville Hallik, Michael Cuddy,Tatsuyuki Satoh, Fabrice Frances, Nicola Salmoria.  (The VZ200 doesn't have an AY sound chip, so why am I listing this?)

Character set	Data by camennie (from his Radio Shack Microcolor Computer MC-10 emulator source)

Microsoft	DirectX, Microsoft Visual C++, Microsoft Development Studio, Windows 95/98.  Thanks, Bill.

ROMs and .VZ files:	See those for their respective credits.

The real VZ200:		VTECH.  I seriously considered working for you guys (the rep you sent to E3 a few years ago was seriously good looking), but I didn't want to relocate to Chicago!

Documentation and programs:
	Lifted, looted, and borrowed from several sources, most of whom are active members of the Yahoo VZ club!  Here are some of my heroes:

  VZ Alive!
        vzalive.bangrocks.com

  Guy Thomason's VZ200 Resource Page
        http://homepage.powerup.com.au/~intertek/VZ200/vz.htm

  Planet VZ
        http://www.fortunecity.com/skyscraper/laser/184/

  The Yahoo group:
        http://games.groups.yahoo.com/group/vzemu/


ABOUT ME:
=========
Name:
	James the Animal Tamer (my parents will tell you my original middle name was not "the Animal").
Age:
	The United States had only 49 states when I was born.  Go figure.
IQ:
	Tested to various numbers between 93 and 153 inclusive.  The extremes were probably bad tests.  I was a member of Mensa, not by dint of my IQ, but rather through my SAT test score.  I was pretty good at multiple guess tests when I was a teenager.
Wired Autism Spectrum Test Score:
	41
Education:  
	Los Angeles Unified School District:  high school graduate
	East LA College:  1 unit.  No one remembers I went there.  I bet it doesn't appear on my transcript, which I haven't checked.
	Caltech: BS (and I'm giving some of it to you)
	Pasadena City College:  Almost enough units to get me an AS, but who cares, since I already had BS from Caltech (and I'm giving you more BS).
Humorous educational note, or still more BS:
	Caltech ("California Institute of Technology" or CIT) was apparently named after California Boulevard in Pasadena, on which it has its address.  It's bordered on the other sides by streets South Wilson, Del Mar, and South Hill (check a map if you don't believe me).  Imagine if it'd been named after one of those other streets.  Do I have to spell it out for you?  Yes?  "South Hill Institute of Technology" or ...look at those initials again!  Still more college humor:  Pasadena City College is bordered by South Hill, Colorado, Del Mar, and "that street that has Burger King on it."  Imagine if it'd been more technical, and named after the street it's on.  Do I have to spell it out?  California Institute of Technology would be just up the street from Colorado Institute of Technology.
Occupation:
	Computer Boy (wow, that was obvious, wasn't it?)
Marital Status:
	Single
Outlook on life:
	My ancestors were slaves.  I am still waiting for an official apology, and reparations, from Rome.  I am not holding my breath.
Former Girlfriends:
	All but one now live more than 500 miles away.
Current Girlfriends:
	Huh?  And spend an evening away from my computer?  (See "Wired Autism Spectrum Test Score" above)
Shoes:
	Size 10.5, extra extra extra wide.  Since I can't find this size anywhere, I wear size 12.  Did I mention I have ancient Briton ancestors?  Will someone from the UK kindly send me some shoes that fit, PLEASE!
Food:
	Purina Bachelor Chow.  Generally eaten cold, directly out of the bag, while standing  over the kitchen sink.
Pets:
	None at present.  Former cat owner.  On friendly terms with two of the neighborhood feral cats (I'd adopt one of them, but she prefers being feral).
Famous quotes:
	"Give me 20 minutes, and I'll give you a college education.  Mine, what I remember of it."
	"An acquired taste is rarely worth acquiring."
