//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by edit.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TYPE_EDIT                   129
#define IDR_TYPE_RICHEDIT               130
#define ID_ESCAPE                       140
#define ID_FORMAT_WORDWRAP              150
#define ID_INDICATOR_POSITION           160
#define IDR_TEXT_POPUP                  170
#define ID_WINDOW_CLOSE                 180
#define ID_FORMAT_FONT                  0xE160

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         200
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
