/* gtkui.h */

#ifdef HAVE_GTK
void gtkui_init(int argc, char **argv);
void gtkui_run( void );
#endif

