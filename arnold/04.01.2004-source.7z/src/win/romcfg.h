#ifndef __ROM_CONFIGURATION_DIALOG_HEADER__
#define __ROM_CONFIGURATION_DIALOG_HEADER__

#include <windows.h>

void	Interface_RomDialog(HWND hwnd);

#endif