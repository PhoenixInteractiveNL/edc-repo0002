#include <windows.h>

void	CheatDatabaseDialog(HWND hParent);
