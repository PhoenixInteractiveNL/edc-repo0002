#ifdef _WIN32
   #define WIN32_EXTRA_LEAN
   #include <windows.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
