#ifndef __CASSETTE_DIALOG_HEADER_INCLUDED__
#define __CASSETTE_DIALOG_HEADER_INCLUDED__

#include <windows.h>

void CassetteControls(HWND);

#endif