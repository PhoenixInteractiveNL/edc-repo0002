The ZLIB DLL (1.1.4) has a ioapi.h header which defines the function 
"fill_fopen_filefunc" but doesn't actually have it in the .lib or .dll :(
