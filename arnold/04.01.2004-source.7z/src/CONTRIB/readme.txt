Arnold extensions by Troels K. 2003-09-24

Files:

emushell.c  - This file is the interface between CPC Loader and Arnold
console.c   - Win32 console support
cpcapi.c    - Interface between Arnold and io device (eg. console)
app.c       - WinMain
libpngw.c   - libpng Win32-wrapper
resfile.c   - Resource 'file' support
unicode.c   - Unicode helper functions
ziphandle.c - Gilles Vollant zip handler
