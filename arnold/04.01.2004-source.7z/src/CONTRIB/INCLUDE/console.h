/* console.h */
/* Win32 console mode support. Copyright (c) Troels K. 2003 */

#ifndef __CONSOLE_H__
#define __CONSOLE_H__

#include "cpcapi.h"

#ifdef __cplusplus
   extern "C" {
#endif

extern const CPCAPI PUB_cpc_console_api;

#ifdef __cplusplus
   }
#endif

#endif /* __CONSOLE_H__ */
