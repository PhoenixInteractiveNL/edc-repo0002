/* unicode.h - Troels K. 2003 */

extern char*    wcstombs_dup(const wchar_t* wcstr);
extern wchar_t* mbstowcs_dup(const char* mbstr);
