Arnold source
(c) Copyright 1995-2002 Kevin Thacker.

This is the source code to Arnold a Amstrad CPC, Amstrad Plus and KC Compact emulator.
This source has been written in C and written to be portable to other systems.

This source is released under the GNU Public License. See the file "Copying"
for the full license.

License:

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

You are welcome to make changes to this source, and if you do I would appreciate
it if you would send me the changes so I can incorporate them into a new source
release.
