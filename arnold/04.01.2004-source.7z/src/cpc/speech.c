
#ifdef SPEECH
			/* SSA-1 */
			if (Port == 0x0fbee)
			{
					CPC_SPO256_WriteData(Data);
			}

			/* Dk'Tronics speech */
	/*      if (Port == 0x0fbfe)
	      {
	              CPC_SPO256_WriteData(NewData);
	      }
	*/
#endif
