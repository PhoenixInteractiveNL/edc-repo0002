#include "language.h"

/* number of languages loaded */
static unsigned long NumLanguages;
/* the language data */
static language_data *LanguageData[16];

