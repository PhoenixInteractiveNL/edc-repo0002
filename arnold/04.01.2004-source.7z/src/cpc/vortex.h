#ifndef __VORTEX_HEADER_INCLUDED__
#define __VORTEX_HEADER_INCLUDED__

void	Vortex_Initialise(void);
void	Vortex_Finish(void);
void	Vortex_RethinkMemory(unsigned char **, unsigned char **);



#endif
