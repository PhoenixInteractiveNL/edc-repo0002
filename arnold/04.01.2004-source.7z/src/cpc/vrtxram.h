#ifndef __VORTEX_RAM_HEADER_INCLUDED__
#define __VORTEX_RAM_HEADER_INCLUDED__

#include "cpc.h"

void	Vortex_RethinkMemory(unsigned char **, unsigned char **);
void	Vortex_Write(Z80_WORD Port, Z80_BYTE Data);

#endif