#ifndef __MAGNUM_HEADER_INCLUDED__
#define __MAGNUM_HEADER_INCLUDED__

#include "cpc.h"

void	Magnum_Update(int,int,int);
void	Magnum_DoOut(Z80_WORD Port, Z80_BYTE Data);

#endif

