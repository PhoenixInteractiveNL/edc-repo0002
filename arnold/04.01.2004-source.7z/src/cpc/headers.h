#ifndef __HEADERS_INCLUDED__
#define __HEADERS_INCLUDED__

#include <stdio.h>
#include <stdlib.h>
#ifndef GBA
#include <memory.h>
#endif
#include <string.h>

#endif

