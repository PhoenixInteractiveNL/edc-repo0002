#ifndef __GUNSTICK_HEADER_INCLUDED__
#define __GUNSTICK_HEADER_INCLUDED__

unsigned long SpanishLightGun_ReadJoystickPort();
void	SpanishLightGun_Update(int, int,int);


#endif