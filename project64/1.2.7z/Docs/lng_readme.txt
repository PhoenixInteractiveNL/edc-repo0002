PJ64 Langauge File (.lng) README
  by users of Project64 around the world =)
    compiled by Smiff
      www.smiff.clara.net
    smiff@smiff.clara.co.uk


Many thanks to everyone who contributed translations. It is great to see Project64 being enjoyed by people all over the world. If you sent a translation, and it didn't make it into this release, I apologise. If I receive several translations for one language I am no position to decide which is the best so I must just pick one. Sorry if you disagree with that choice.

If you would like to contribute a language file for Project64, please copy the English template below and paste it into a new text document named "Project64.lng" in the root of your PJ folder (move the existing file) and please follow these points carefully:


IMPORTANT DOs and DON'Ts of making language files for Project64:

DO use NOTEPAD to edit the .lng file - it is (it must be) plain text.
DO edit AFTER the "=" sign of each line.
DO use the "&" symbol is to set sensible keyboard shortcuts for every menu item.
DO make sure text fits the space available in the GUI.
DO abbreviate sensibly where necessary.
DO put header in the language and English please, e.g. "[Deutsch (German)]" not "[German]" or "[Deutsch]".
DO include your (nick)name and email, commented out with "//", after the language title.
Do test your file to check for mistakes.
Do email your file to me (Smiff), not Zilmar or Jabo.
Do put the language name in the subject of the email.

Do NOT edit anything before an "=" sign, you will break the file!
Do NOT try to use more than one line per item, you can't control line breaks.
DO NOT worry that there is some text on the GUI that you cannot set ;)
Do NOT try to translate where no common word exists in the language :P
Do NOT send me the english version with your file!
Do NOT send me a language that's already in the latest version, unless there's a very good reason.




{begin file template, start copying here}

[YourLanguageNameHere]
//by {Your name and email here}
MenuTitle1=&File
MenuTitle2=&System
MenuTitle3=&Options
MenuTitle4=&Help
FileItem1=&Open Rom
FileItem2=&Rom Info
FileItem3=&Start Emulation
FileItem4=&End Emulation
FileItem5=E&xit
SystemItem1=&Reset
SystemItem2=&Pause
SystemItem3=&Generate Bitmap
SystemItem4=&Save
SystemItem5=&Restore
SystemItem6=Current Save S&tate
SaveSlotItem1=Default
SaveSlotItem2=Slot 1
SaveSlotItem3=Slot 2
SaveSlotItem4=Slot 3
SaveSlotItem5=Slot 4
SaveSlotItem6=Slot 5
SaveSlotItem7=Slot 6
SaveSlotItem8=Slot 7
SaveSlotItem9=Slot 8
SaveSlotItem10=Slot 9
SaveSlotItem11=Slot 10
OptionsItem1=&Full Screen
OptionsItem2=Configure &Graphics Plugin...
OptionsItem3=Configure &RSP Plugin...
OptionsItem4=Configure &Audio Plugin...
OptionsItem5=Configure &Controller Plugin...
OptionsItem6=Gameshark codes (&Cheats)
OptionsItem7=&Settings...
OptionsItem8=&Language
HelpItem1=&About Project 64
MenuDes1=Open an existing n64 rom image
MenuDes2=Display infomation about the current rom
MenuDes3=starts emulation of the current loaded rom
MenuDes4=stop emulation of the current loaded rom
MenuDes5=Quit the application
MenuDes6=Restart the CPU
MenuDes7=Pause the CPU
MenuDes8=Save the current state of the cpu
MenuDes9=Restore the current state of the cpu
MenuDes10=Display the programs information
MenuDes11=Load a previous loaded rom
SettingsTab1=Plugins
SettingsTab2=Directories
SettingsTab3=Options
SettingsTab4=Rom Options
AboutButton=About
PluginType1=Reality Signal Processor
PluginType2=Graphics
PluginType3=Audio
PluginType4=Controller
StoreDirName1=Plugin Directoy
StoreDirName2=Rom Directory
StoreDirName3=N64 Auto saves
StoreDirName4=Instant saves
StoreDirName5=Snap Shots
DefaultRomDir=Last folder that a rom was open from.
CPUType1=Default
CPUType2=Interpreter
CPUType3=Recompiler
SelfModMethod1=Default
SelfModMethod2=None
SelfModMethod3=Cache
SelfModMethod4=Protect Memory
SelfModMethod5=Check Memory
SelfModMethod6=Check Memory & Cache
RDRAMSize1=Default
RDRAMSize2=4mb
RDRAMSize3=8mb
MaxSpeed1=Default
MaxSpeed2=50 vi/sec
MaxSpeed3=60 vi/sec
MaxSpeed4=No Max Speed
SaveType1=UseFirstSaveType
SaveType2=4kbit Eeprom
SaveType3=16kbit Eeprom
SaveType4=32kbytes SRAM
SaveType5=Flashram
OptionsText1=Most of these changes will not take effect till a new rom is opened or current rom is reset.
OptionsText2=Start Emulation when rom is opened?
OptionsText3=Pause emulation when window is not active?
OptionsText4=Disable Register caching?
OptionsText5=Always overwrite default settings with ones from ini?
OptionsText6=CPU core style:
OptionsText7=Method to handle self-modifying code:
OptionsText8=Default Memory Size:
OptionsText9=Maximum speed:
OptionsText10=Recent File List contains (Max 10):
OptionsText11=roms
RomOptionsText1=Default Memory Size:
RomOptionsText2=Default Save type:
RomOptionsText3=CPU core style:
RomOptionsText4=Self-modifying code Method:
RomOptionsText5=Max Speed:
RomOptionsText6=Always Use TLB

{stop copying, end of file template}


Then attach the file to an email and send to me (Smiff), clearly marked with the language name in the subject line and your (nick)name and return email address in the body so I can credit you. If you don't want your name/email published say so. If you speak some weird regional variant of your language please make that clear, I am no cunning linguist...


Thanks in advance for your contributions!


[EOF]
