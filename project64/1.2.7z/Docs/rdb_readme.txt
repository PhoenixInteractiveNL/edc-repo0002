PJ64 Official ROM Database (Project64.rdb) README
   by Smiff
      www.smiff.clara.net
    smiff@smiff.clara.co.uk

Turn on 'Word Wrap' if you are viewing this file in Notepad!



TABLE OF CONTENTS

1) INTRO
2) GAME LIST
3) NOTES
4) TIPS
5) THANKS




1) INTRO

There are no 'degrees of playable' with the official PJ64 RDB series. If it's here, then it works - as far as we know.

If you find a game in the official RDB has problems that are serious enough to stop you playing, please post the info to the Project64 forum (currently hosted at www.emulation64.com), where I and the authors will see it. If possible, make a state save just before the problem, one of us may ask for it (but first, read on!).

The file contains VERIFIED GOOD DUMPS ([!]&[a]) ONLY. I highly recommend everyone download and use GoodN64 w/ GoodWindows. In fact, running GoodN64 on your ROMs is pretty much compulsory if you want any kind of support. Bad[b]/hacked[h]/trained[t]/fixed[f] ROMs are not supported in PJ64. Overdumps[o] you may need to add yourself, but they should work.

Unless otherwise stated, all regions (U,E,J etc.) and all versions (v1.0, v1.1 etc.) of a particular game work equally in PJ64.

All game titles are taken from GoodN64. Any errors in titles should be errors in GoodN64.

And always: if the ROM isn't in the Official RDB, or you've added it yourself, you're on your own!




Please do NOT post any known issues to the forum. This irritates both the authors and other users. You can read a list of known issues on my website. It is updated regularly.

Please do NOT send us save files or screenshots unless we ask for them - getting large attachments over a modem isn't fun, and when we aren't having fun, you aren't getting replied to. If we do ask, be sure to compress saves using WinZIP, or preferably, WinRAR and state your GoodN64 ROM filename so we have some chance of being able to load them. Screenshots need only be large enough to show the problem, and must be converted to JPEG format using Photoshop or similar shareware application. Just zipping a .bmp is not good enough!

Please do NOT bother the authors about games NOT marked with the 'tested by authors before release' symbol. They never said they worked, I did. So bother me instead ;) But not until you've read the FAQ and Known Issues pages on my site!

If this all sounds mean, it's not meant to be. There are God knows how many 100s of thousands of people out there using Project64, two authors (that would be Zilmar and Jabo), one INI writer (that would be me), and limited free time on everyone's part.




2) GAME LIST:

This RDB contains entries for good ROMs of the following games. I believe they are all playable in PJ64:

1080 Snowboarding�
AeroGauge
Airboarder 64
All Star Tennis '99*
Asteroids Hyper 64
Automobili Lamborghini/Super Speed Race 64
Banjo-Kazooie*�
Batman Beyond - Return of the Joker
BattleTanx
BattleTanx - Global Assault 
Beast Wars Transmetal*
Big Mountain 2000
Blast Corps/Blast Dozer*
Blues Brothers 2000
Body Harvest*
Bomberman Hero
Bust-A-Move '99/Bust-A-Move 3 DX/Puzzle Bobble 64�
California Speed
Castlevania - Legacy of Darkness/AkumajoDracula MokushirokGaiden - Legend of Cornell*
Castlevania�
Chameleon Twist (region J only)
Charlie Blast's Territory
Chopper Attack/Wild Choppers
Choro Q 64 II
Clay Fighter - Sculptor's Cut
Clay Fighter 63 1-3
Clay Fighter Beta*
Command and Conquer
Cruis'n USA*
Cruis'n World*
CyberTiger*
Destruction Derby 64*
Doom 64
Doraemon - Mittsu no Seireiseki
Duke Nukem - ZER0 H0UR*
Duke Nukem 64
Earthworm Jim 3D*
Excitebike 64*/Excitebike 64 - Kiosk*
Extreme-G*
F-Cup Maniax
Fighter's Destiny/Fighting Cup
Forsaken 64
Fox Sports College Hoops '99
F-Zero X*�
Gex 64 - Enter the Gecko
Glover
Goemon's Great Adventure/Ganbare Goemon 2 - Deoru Dero Douchuu Obake Tenkomori/Mystical Ninja 2 - Starring Goemon
GoldenEye 007*�
Human Grand Prix/F-1 Pole Position 64*
Hybrid Heaven
Iggy's Reckin' Balls
Jikkyou Pawapuro Puroyakyu 2000
Killer Instinct Gold*�
Kiratto Kaiketsu! 64 Tanteidan
Legend of Zelda 2, The - Majora's Mask/Zelda no Densetsu 2 - Mujura no Kamen*�
Legend of Zelda, The - Ocarina of Time/Zelda no Densetsu - Toki no Ocarina*�
LEGO Racers*
Mace - The Dark Age*
Magical Tetris Challenge*
Mahjong Hourouki Classic
Mario Golf 64�
Mario Kart 64�
Mario Party 2*
Mario Party*
Mega Man 64/Rockman Dash*
Micro Machines 64 Turbo
Milos Astro Lanes
Mischief Makers
Monaco Grand Prix*
Monopoly
Monster Truck Madness 64
Mortal Kombat 4
Mortal Kombat Trilogy 
MRC - Multi Racing Championship*
Nagano Olympic Hockey '98
Nagano Winter Olympics 98 (region J only)
NBA In the Zone '98/NBA Pro 98
NBA In the Zone '99/NBA Pro 99
NHL Blades of Steel '99/NHL Pro 99
Paperboy
Pawapuro Puroyakyu 4 (Power Baseball 4)
Pawapuro Puroyakyu 5 (Power Baseball 5)
Pokemon Stadium 2*
Pokemon Stadium GS*
Pokemon Stadium/Pokemon Snap Station - Kiosk*
Quake II*
Quest 64/Holy Magic Century/Eltale Monsters
Racing Simulation - Monaco Grand Prix/Racing Simulation 2*
Rakuga Kids
Rally Challenge 2000*
Rampage - World Tour*
Rat Attack
Ready 2 Rumble Boxing Round 2
Ready 2 Rumble Boxing* (region E fails recompiler)
Robotron 64
Rocket - Robot on Wheels
RR64 - Ridge Racer 64�
Rush 2 - Extreme Racing USA*
San Francisco Rush - Extreme Racing*
San Francisco Rush 2049* (turn off sound!)
Scooby-Doo - Classic Creep Capers
Snowboard Kids
Snowboard Kids 2/Chou Snowbow Kids*
Space Invaders
Spacestation Silicon Valley* (region E only)
Star Fox 64/Lylat Wars�
Star Soldier Vanishing Earth
Super Mario 64 Shindou Edition
Super Mario 64�
Super Smash Bros.�
Superman
Tetrisphere
Tigger's Honey Hunt
Tom and Jerry in Fists of Furry*
Tony Hawk's Pro Skater*
Top Gear Rally 2*
Virtual Chess 64
Waialae Country Club - True Golf Classics
War Gods
Wave Race 64 Shindou Edition
Wave Race 64�
Wetrix (region J fails recompiler)
Wheel of Fortune
Xena Warrior Princess - Talisman of Fate


123 Titles / 288 ROMs

Remember to check my web site (URL at top) for new RDB releases, which should improve compatibility and performance, as well as giving you the most complete guide to what's currently playable in PJ64.




3) NOTES

MemPaks
Some of the games in the RDB use the 'MemPak' (Controller Pack) to save. This save type is currently not working properly in PJ64 - it seems to be cleared after you exit. Thus you may need to use state saves to save your progress. Some games are apparently impossible to enter because of MemPak issues. Try using the in-game repair option, then hitting reset (er, on PJ, not your PC...).

Testing & Stability
Games added in updated RDBs are not as well tested as those in the 1st release. They have passed some basic checks only (booting, graphics, sound, control, and stability for just a short while!). So consider these updated RDBs a public beta (alpha?) test of the games in PJ64. It is possible that I haven't used a sufficiently strong self-mod code method, because I am always striving for performance as well as compatibility. If in doubt, try 'Protect Memory'. Then try running on the interpreter. Then try disabling Register Caching. If it still crashes the core, only the authors can fix it.

Self-mod code Methods
I have upped the security (self-mod method) on some games since the 1st release, e.g. Banjo-Kazooie, due to doubts about stability. Thus a game that you found crashed before may no longer do so on the newest RDB.

Settings Variation between Regions
You may notice that not all entries for a game have the same settings. These are not mistakes! Bugs in PJ64 mean that, for example, region E of the game "Goldeneye 007" does not work on the recompiler, whilst other regions do. Originaly I excluded such ROMs but later decided to include them with the necessary (slower) settings, for absolute clarity.

Overdumps
These are ROMs which contain more data than the they should, often two images of the same game. The CRCs usually match a known good ROM and the ROM contains a good image, so then it runs fine in PJ64. When it doesn't, the only reason I haven't included them in the RDB is time constraints - feel free to add any yourself, by matching the settings to mine. Personally, I would locate and use a known good ROM simply because that saves hard drive space and reduces load time... plus the game will already be configured correctly :)

Missing Region Name Variants
I try my best to find all different regions of each game. Sometimes this is difficult because the Japanese name, when translated into English, is different to the name the game has in the West. If I have missed any such cases, please email me the info, I would be most grateful.




4) TIPS

...did you know?

- PJ64 can load zipped ROMs.
- Sometimes you can speed up PJ by state saving>loading.
- You can edit the RDB through the GUI.
- You can use safer settings to get through a crash point, state save, switch settings back, and state load.

PJ will automatically create new entries or modify existing ones as appropriate. This is good (because it often saves you having to edit the file by hand) and this is bad (because you can mess up my existing settings and render games unplayable).

If you find a game that used to work for you, no longer works (in the same version of PJ64), follow the PJ64 uninstall instructions on my site.




5) THANKS

I want to say special thanks to:

Cowering and Master of Puppets, without whose tools this file would not be possible, and we'd all be in a world of shit. ;) Seriously, think about it.

The users on the Emulation64 forum for their feedback and compatibility lists, it was very useful in making these updates :)

Last but oh-so-not least, Zilmar and Jabo.


Remember you can thank the authors by making a donation.


If you use my RDB as a base for your own, and you want to release it, please:
1) Make it clear that it's unofficial. 'Unofficial' =/= 'Worse', of course!
2) Use your own version numbering system (not "vX.X.XX")
3) Credit the PJ64 authors and myself.


[EOF]
