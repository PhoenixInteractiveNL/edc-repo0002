Project64 Simple Uninstall Scripts
   by Smiff
      www.smiff.clara.net
    smiff@smiff.clara.co.uk


These are .reg (Microsoft Registry Editor) files which delete the various Project64 registry keys from your system. This is an alternative to performing the task by hand for people who are not confident using REGEDIT.

You will find with experience that this .reg file method is quicker and easier than a full uninstaller app (.exe), not to mention the smaller file sizes!

You have the choice of removing a specific version of PJ64, or all versions of PJ64 at once, depending which file you run.

Note that these files do NOT delete your Project64 folder on your hard drive, ONLY the Project64 registry entries. You can delete your Project64 folder with your delete key ;)

These .reg files have been well tested and should pose no risk to your system but backing up your Windows registry is general good practice. I and the Project64 team are not responsible for any harm that results from your use or incorrect use of these files.


Things you might like to BACKUP before you begin:
-------------------------------------------------
1)Your SAVES folders (both N64 native saves and State saves)
2)Your input configuration (remember you can export it to a file)
3)Your INI file if you have modified it, or added games to it
4)Any 3rd party plugins you might have copied to your \plugin\ subfolder
5)Any ROMs you might have in a subfolder
6)Your Windows registry, if you want to be 100% safe.



To un/re-install a specific version of Project64 from your registry:
--------------------------------------------------------------------
1) Check which version of Project64 you have by looking at the program title bar
2) Exit the Project64 application
3) Double click the correct .reg file for the version of PJ64 you wish to uninstall
4) You will be asked "Are you sure you want to add the information in ... to the registry?"
5) You must answer "YES"
6) You will be told "Information in ... has been successfully entered into the registry."
7) Delete the .reg file.

If you are reinstalling PJ64, go to step 8a
If you are uninstalling PJ64, go to step 8b

8a) (reinstalling only) When you restart Project64 and press OK on the various configuration dialogues it will recreate the registry keys with default values (unless of course you changed anything in the dialogues).
8b) (uninstalling only) Simply delete your Project64 folder after following the steps above and you're done, there is no trace of the installed emulator left on your system.



To un/re-install all versions and remove all traces of Project64 from your registry:
------------------------------------------------------------------------------------
Repeat steps 2-8 above but replace step 3 with
3) Double click the file "REMOVE ALL PJ64 VERSIONS COMPLETELY.reg"
Note this should work on past and future versions of Project64, but check my site for updates to this package.



NOTES:
------
You do not need to reboot your system after running these files - changes take effect immediately.

Be warned that there is no 'undo' feature, so make a note of your PJ64 settings if you are concerned you might need and forget them. Remember you can export your input configuration to a file.

Note that if you use the Project64 plugins in other emulators then these files will also remove those settings - this is unavoidable due to the shared registry locations. You may wish to delete by hand in this case.