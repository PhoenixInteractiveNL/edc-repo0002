Project 64 Official Cheats Database (Project64.cht) README
    by Eagle

Maximize this window if you are having trouble viewing it.

Table Of Contents
  I.   Introduction
  II.  Installation
  III. FAQ
  IV.  Contacting Me
  V.   Thanks



I.   Introduction

I complied this database of Game Shark cheat codes in order to make it easy for PJ64 users
to add a little extra life to the games they have played dozens of times and long forgotten
about.  I hope you enjoy being able to use these codes.  Should you find a code that is not
working read the section on contacting me further down the page.



II.   Installation

Installation is an easy task.  Simply extract the contents of this archive to the Project 64
software's directory.  This archive should contain the following files:

   Project64.cht              - The actual cheats database file
   ReadMe.txt     	      - This readme file
   WhatsNew.txt               - A list of changes made since the previous version


III.  FAQ

Question: Why are there no codes for foreign games in the database?
Anwer:    Game Shark is a company based in the United States and does not test, hack, or
          support foreign game cartridges, therefore there are no cheats available for
          foreign games.  While there are a few codes floating around for foreign imports,
          they are very difficult to find and most likely will not produce the desired
          effect.  Due to these circumstances, they are not included in this database.

Question: What does "Code 1, Code 2, etc." mean?
Answer:   These are cheats that have more than 8 codes (the limit set by the PJ64 GUI).  In
	  order to include all the codes it was split between two or more cheats.  All of
	  the cheats with this name must be activated to achieve the entire desired result.

Question: Why do some games in the database not have any cheat codes?
Answer:   These are games/versions that are found in Smiff's RDB (matching the build number
          found top of the database file) but no cheats are currently available.  If you
	  have a code for one of these games, send it to me (see section on contacting
	  me below)

Question: What does the Version/Build number mean?
Answer:   The Version number is exactly what it says.  The Build number is the version
	  number of "Smiff's Official Project 64 Rom Database (RDB)" in which this
	  database version is based on.  Sometimes build numbers may be behind current
	  versions of Smiff's RDB.


III. Contacting Me

The best way to contact me is through private messages on the Emulation 64 forums 
(www.emulation64.com).  Log-in and click "Messenger" at the top of the page.  My 
user name is Eagle018.  You may also e-mail me at KPSeiden@aol.com, make sure the
topic of your email is clearly noticable to the cheats file (ex. "Project 64 Cheats") 
because I do recieve a lot of junk mail and if I don't recognize the e-mail address it may
be deleted without being read. Please read the following before contacting me.

Reasons to Contact Me:

1. To notify me of a code(s) that are not producing the desired effect.  NOTE: Check to see
   that you are using a GoodN64 approved region [U] rom before contacting me.
2. To send me a code I don't have for a game currently in the database. Please test all
   codes before sending them with region [U] roms.
3. To notify me of a game that is in Smiff's RDB and not in my database (rare, but I do
   miss them sometimes).  Only games found in Smiff's RDB that match the build number of
   the cheat database are guaranteed to be found in the cheat database, do not contact me
   about any games found in newer versions of the RDB.

Reasons NOT to Contact Me:

1. To request a game to be added to the cheat database.  If the game is supported by Smiff's
   RDB then it is in the cheat database, otherwise it may or may not be.
2. To request a code that produce a desired effect for a game.  Trying to find a code based
   on the effect is difficult if not impossible.
3. To send me a code(s) for games not currently in the database.  Please wait until the game 
   has been entered in the database before sending me codes for it.  I may already have
   them.
4. To ask me how to fix a game or get it to work on Project 64.  If your having problems,
   read Smiff's rdb_readme.txt in the Project 64 "docs" folder, it should inform you of
   everything you need to know to find answers to your problem.

NOTE: It is not appropriate to post lists of cheat codes for me to add to my database as a
      thread on the Project 64 message forum.  The forum can be used to inform others as
      well as myself about codes that do not work or to gain help using the cheat codes.  Do
      not e-mail the Project 64 authors or Smiff about problems that you find in the cheats
      database, instead contact me and I will attempt to correct them.



IV. Thanks

To begin, I would like to thank all those on the Project 64 forums who supported me while
testing this database file.  I would like to thank Smiff for the reference of his Official
Project 64 RDB and for help distributing it through his web page. I also would like to thank
Jabo and Zilmar for the production of this great emulator and correcting support issues in
Project 64 and Jabo, Zilmar, and Smiff for the encouragment they gave me while producing
this database.