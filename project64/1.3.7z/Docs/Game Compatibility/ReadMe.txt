PJ64 Official ROM Database (Project64.INI) ReadMe.txt
   by Smiff
      www.smiff.clara.net
    smiff@smiff.clara.co.uk

Turn on 'Word Wrap' if you are viewing this file in Notepad!



Table of Contents

1) INTRODUCTION
2) THE BIG LIST
3) IMPORTANT NOTES <--please read this bit!
4) TIPS
5) THANKS




1) INTRODUCTION

There are no 'degrees of playable' with the official PJ64 INI series. If it's here, then it simply works pretty well - as far as we know. If it isn't here, it _probably_ has some nasty flaws in emulation.

The file contains GOODN64 VERIFIED GOOD DUMPS (known as "ReDumps", files marked [!]) ONLY. I highly recommend everyone download and use GoodN64 with GoodWindows. In fact, running GoodN64 on your ROMs is pretty much compulsory if you want any kind of tech. support. Bad[b], hacked [h], trained[t], or fixed[f] ROMs are not supported in PJ64. Overdumps[o] you may need to add yourself, but they should work.

All game titles are taken from GoodN64. The entire INI is based around the current version of GoodN64 at the time of release, in this case v0.999.5.

If you find a game in the official INI has problems that are serious enough to stop you playing, please first read this document thoroughly and check the Known Issues webpage, then please read the Bug Reporting document provided for further instructions.

And always: if the ROM isn't in the Official INI, or you've added it yourself, you're on your own!


Please do NOT post any known issues to the forum. This irritates both the authors and other users. You can read a list of known issues on my website. It is updated regularly.

Please do NOT bother the authors about games NOT marked with the 'tested by authors before release' symbol. They never said they worked, I did. So bother me instead ;) But not until you've read this document, the FAQ, and the Known Issues page on my site!


If this all sounds mean, it's not meant to be. There are probably many hundreds of thousands of people out there using Project64, two authors (that would be Zilmar and Jabo), one INI writer (that would be me), a few other dedicated people helping us out, and limited free time on everyone's part.




2) THE BIG LIST:

This INI contains entries for the following ROMs. I believe they are all playable in PJ64. SEE ISSUES PAGE (URL provided in \docs\ folder) FOR POSSIBLE KNOWN ISSUES & WORKAROUNDS IN THESE GAMES! Whilst we try to maintain the highest standards in emulation quality, please don't expect perfection, as always: if you just want to play games without hassle, buy the real thing.


[ ] 1080 Snowboarding (E) [!] (PJ v1.2 recommended)
[ ] 1080 Snowboarding (JU) [!] (PJ v1.2 recommended)
[ ] A Bug's Life (E) [!]
[ ] A Bug's Life (F) [!]
[ ] A Bug's Life (G) [!]
[ ] A Bug's Life (U) [!]
[ ] A Bug's Life (U) [a1][!]
[ ] Aerofighter's Assault (E) [!]
[ ] Aerofighter's Assault (U) [!]
[ ] AeroGauge (E) [!]
[ ] AeroGauge (J) (V1.1) [!]
[ ] AeroGauge (U) [!]
[ ] Airboarder 64 (E) [!]
[ ] Airboarder 64 (J) [!]
[ ] Akumajou Dracula Mokushiroku - Real Action Adventure (J) [!]
[ ] Akumajou Dracula Mokushiroku Gaiden - Legend of Cornell (J) [!]
[ ] Alice no Wakuwaku Trump World (J) [!]
[ ] All Star Tennis '99 (E) [!]
[ ] All Star Tennis '99 (U) [!]
[ ] All Star! Dairantou Smash Brothers (J) [!]
[ ] All-Star Baseball 99 (E) [!]
[ ] Army Men - Air Combat (U) [!]
[ ] Army Men - Sarge's Heroes (E) [!]
[ ] Army Men - Sarge's Heroes (U) [!]
[ ] Army Men - Sarge's Heroes 2 (U) [!]
[ ] Asteroids Hyper 64 (U) [!]
[ ] Automobili Lamborghini (E) [!]
[ ] Automobili Lamborghini (U) [!]
[ ] Baku Bomberman (J) [!]
[ ] Bakushou Jinsei 64 - Mezase! Resort Ou (Game of Life) (J) [!]
[ ] Banjo to Kazooie no Dai Bouken (J) [!]
[ ] Banjo-Kazooie (U) [!]
[ ] Bass Tsuri No. 1 - Shigesato Itoi's Bass Fishing (J) [!]
[ ] Batman Beyond - Return of the Joker (E) [!]
[ ] Batman Beyond - Return of the Joker (U) [!]
[ ] BattleTanx - Global Assault (E) [!]
[ ] BattleTanx - Global Assault (U) [!]
[ ] BattleTanx (U) [!]
[ ] Beast Wars Transmetal (U) [!]
[ ] Beetle Adventure Racing! (J) [!]
[ ] Beetle Adventure Racing! (U) [!]
[ ] Big Mountain 2000 (U) [!]
[ ] Blast Corps (U) (V1.0) [!]
[ ] Blast Corps (U) (V1.1) [!]
[ ] Blast Dozer (J) [!]
[ ] Blues Brothers 2000 (E) [!]
[ ] Blues Brothers 2000 (U) [!]
[ ] Body Harvest (E) [!]
[ ] Body Harvest (U) [!]
[ ] Bokujo Monogatari 2 (J) [!]
[ ] Bomberman Hero (E) [!]
[ ] Bomberman Hero (J) [!]
[ ] Bomberman Hero (U) [!]
[ ] Bust-A-Move 3 DX (E) [!]
[ ] Bust-A-Move '99 (U) [!]
[ ] California Speed (U) [!]
[ ] Castlevania - Legacy of Darkness (E) [!]
[ ] Castlevania - Legacy of Darkness (U) [!]
[ ] Castlevania (E) [!]
[ ] Castlevania (U) [!]
[ ] Chameleon Twist (E) [!]
[ ] Chameleon Twist (J) [!]
[ ] Chameleon Twist (U) [!]
[ ] Charlie Blast's Territory (E) [!]
[ ] Charlie Blast's Territory (U) [!]
[ ] Chopper Attack (E) [!]
[ ] Chopper Attack (U) [!]
[ ] Choro Q 64 II (J) [!]
[ ] Chou Snowbow Kids (J) [!]
[ ] Clay Fighter - Sculptor's Cut (U) [!]
[ ] Clay Fighter (beta) (U) [!]
[ ] Clay Fighter 63 1-3 (E) [!]
[ ] Clay Fighter 63 1-3 (U) [!]
[ ] Command & Conquer (E) [!]
[ ] Command & Conquer (G) [!]
[ ] Command & Conquer (U) [!]
[ ] Conker's Bad Fur Day (E) [!]
[ ] Conker's Bad Fur Day (U) [!]
[ ] Cruis'n USA (E) [!]
[ ] Cruis'n USA (U) (V1.0) [!]
[ ] Cruis'n USA (U) (V1.1) [!]
[ ] Cruis'n USA (U) (V1.2) [!]
[ ] Cruis'n World (E) [!]
[ ] Cruis'n World (U) [!]
[ ] CyberTiger (E) [!]
[ ] CyberTiger (U) [!]
[ ] Deadly Arts (U) [!]
[ ] Defi au Tetris Magique (Magical Tetris Challenge) (F) [!]
[ ] Destruction Derby 64 (E) [!] (PJ v1.2 recommended)
[ ] Destruction Derby 64 (U) [!] (PJ v1.2 recommended)
[ ] Dezaemon 3D (J) [!]
[ ] Disney's Donald Duck - Goin' Quackers (U) [!]
[ ] Dobutsu No Mori (J) [!]
[ ] Donald Duck - Quack Attack (E) [!]
[ ] Doom 64 (E) [!] (PJ v1.2 recommended)
[ ] Doom 64 (J) [!] (PJ v1.2 recommended)
[ ] Doom 64 (U) [!] (PJ v1.2 recommended)
[ ] Doraemon - Mittsu no Seireiseki (J) [!]
[ ] Dual Heroes (E) [!]
[ ] Dual Heroes (U) [!]
[ ] Duck Dodgers Starring Daffy Duck (U) [!]
[ ] Duke Nukem - ZER0 H0UR (E) [!]
[ ] Duke Nukem 64 (E) [!]
[ ] Duke Nukem 64 (U) [!]
[ ] Earthworm Jim 3D (E) [!]
[ ] Earthworm Jim 3D (U) [!]
[ ] ECW Hardcore Revolution (E) [!]
[ ] ECW Hardcore Revolution (U) [!]
[ ] Elmo's Letter Adventure (U) [!]
[ ] Elmo's Number Journey (U) [!]
[ ] Eltale Monsters (J) [!]
[ ] Excitebike 64 - Kiosk (U) [!]
[ ] Excitebike 64 (E) [!]
[ ] Excitebike 64 (J) [!]
[ ] Excitebike 64 (U) [!]
[ ] Extreme-G (E) [!]
[ ] Extreme-G (J) [!]
[ ] Extreme-G (U) [!]
[ ] F-1 Pole Position 64 (E) [!]
[ ] F-1 Pole Position 64 (U) [!]
[ ] F-1 World Grand Prix (E) [!]
[ ] F-1 World Grand Prix (F) [!]
[ ] F-1 World Grand Prix (J) [!]
[ ] F-1 World Grand Prix (U) [!]
[ ] F-1 World Grand Prix II (E) [!]
[ ] F-Cup Maniax (J) [!]
[ ] Fighter's Destiny (E) [!]
[ ] Fighter's Destiny (F) [!]
[ ] Fighter's Destiny (G) [!]
[ ] Fighter's Destiny (U) [!]
[ ] Fighter's Destiny 2 (U) [!]
[ ] Fighting Cup (J) [!]
[ ] Fighting Force 64 (E) [!]
[ ] Fighting Force 64 (U) [!]
[ ] Forsaken 64 (E) [!]
[ ] Forsaken 64 (G) [!]
[ ] Forsaken 64 (U) [!]
[ ] Fox Sports College Hoops '99 (U) [!]
[ ] Fushigi no Dungeon - Furai no Shiren 2 (J) [!]
[ ] F-Zero X (E) [!]
[ ] F-Zero X (J) [!]
[ ] F-Zero X (U) [!]
[ ] G.A.S.P! Fighter's NEXTream (E) [!]
[ ] G.A.S.P! Fighter's NEXTream (J) [!]
[ ] Ganbare Goemon 2 - Deoru Dero Douchuu Obake Tenkomori (J) [!]
[ ] Ganbare Nippon Olympics 2000 (J) [!]
[ ] Getter Love!! Cho Renai Party Game (J) [!]
[ ] Gex 3 - Deep Cover Gecko (E) [!]
[ ] Gex 3 - Deep Cover Gecko (FG) [!]
[ ] Gex 3 - Deep Cover Gecko (U) [!]
[ ] Gex 64 - Enter the Gecko (E) [!]
[ ] Gex 64 - Enter the Gecko (U) [!]
[ ] Glover (E) [!]
[ ] Glover (U) [!]
[ ] Goemon's Great Adventure (U) [!]
[ ] GoldenEye 007 (E) [!]
[ ] GoldenEye 007 (J) [!]
[ ] GoldenEye 007 (U) [!]
[ ] Harvest Moon 64 (U) [!]
[ ] Hercules - The Legendary Journeys (E) [!]
[ ] Hercules - The Legendary Journeys (U) [!]
[ ] Hexen (E) [!]
[ ] Hexen (J) [!]
[ ] Hexen (U) [!]
[ ] Holy Magic Century (E) [!]
[ ] Holy Magic Century (E) [a1]
[ ] Holy Magic Century (F)
[ ] Holy Magic Century (G) [!]
[ ] Human Grand Prix (J) [!]
[ ] Hybrid Heaven (E) [!]
[ ] Hybrid Heaven (J) [!]
[ ] Hybrid Heaven (U) [!]
[ ] Iggy's Reckin' Balls (E) [!] (PJ v1.2 recommended)
[ ] Iggy's Reckin' Balls (U) [!] (PJ v1.2 recommended)
[ ] International Superstar Soccer 64 (E) [!]
[ ] International Superstar Soccer 64 (U) [!]
[ ] International Superstar Soccer '98 (E) [!]
[ ] International Superstar Soccer '98 (U) [!]
[ ] International Track and Field Summer Games (E) [!]
[ ] J. League Dynamite Soccer (J) [!]
[ ] J. League Tactics Soccer (J) [!]
[ ] Jeopardy! (U) [!]
[ ] Jeremy McGrath Supercross 2000 (E) [!]
[ ] Jeremy McGrath Supercross 2000 (U) [!]
[ ] Jikkyou G1 Stable (J) [!]
[ ] Jikkyou J. League 1999 - Perfect Striker 2 (J) [!]
[ ] Jikkyou Pawapuro Puroyakyu 2000 (J) [!]
[ ] Jikkyou Powerful Pro Baseball Basic 2001 (J) [!]
[ ] Jikkyou World Cup France '98 (J) [!]
[ ] Jikkyou World Soccer 3 (J) [!]
[ ] Jinsei Game 64 (J) [!]
[ ] John Romero's Daikatana (E) [!]
[ ] John Romero's Daikatana (J) [!]
[ ] John Romero's Daikatana (U) [!]
[ ] Killer Instinct Gold (E) [!]
[ ] Killer Instinct Gold (U) (V1.0) [!]
[ ] Killer Instinct Gold (U) (V1.1) [!]
[ ] Killer Instinct Gold (U) (V1.2) [!]
[ ] Kiratto Kaiketsu! 64 Tanteidan (J) [!]
[ ] Legend of Zelda 2, The - Majora's Mask (E) [!]
[ ] Legend of Zelda 2, The - Majora's Mask (U) [!]
[ ] Legend of Zelda, The - Ocarina of Time (E) (V1.0) [!]
[ ] Legend of Zelda, The - Ocarina of Time (E) (V1.1) [!]
[ ] Legend of Zelda, The - Ocarina of Time (U) (V1.0) [!]
[ ] Legend of Zelda, The - Ocarina of Time (U) (V1.1) [!]
[ ] Legend of Zelda, The - Ocarina of Time (U) (V1.2) [!]
[ ] LEGO Racers (E) [!]
[ ] LEGO Racers (U) [!]
[ ] LEGO Racers (U) [a1][!]
[ ] Looney Tunes - Duck Dodgers (E) [!]
[ ] Lylat Wars (A) [!]
[ ] Lylat Wars (E) [!]
[ ] Mace - The Dark Age (E) [!]
[ ] Mace - The Dark Age (U) [!]
[ ] Madden Football 64 (E) [!]
[ ] Madden Football 64 (U) [!]
[ ] Magical Tetris Challenge (E) [!]
[ ] Magical Tetris Challenge (G) [!]
[ ] Magical Tetris Challenge (J) [!]
[ ] Magical Tetris Challenge (U) [!]
[ ] Mahjong 64 (KOEI) (J) [!]
[ ] Mahjong Hourouki Classic (J) [!]
[ ] Mahjong Master (J) [!]
[ ] Mario Golf (E) [!]
[ ] Mario Golf (U) [!]
[ ] Mario Golf 64 (J) [!]
[ ] Mario Kart 64 (E) (V1.0) [!]
[ ] Mario Kart 64 (E) (V1.1) [!]
[ ] Mario Kart 64 (J) (V1.0) [!]
[ ] Mario Kart 64 (J) (V1.1) [!]
[ ] Mario Kart 64 (U) [!]
[ ] Mario Party (E) [!]
[ ] Mario Party (J) [!]
[ ] Mario Party (U) [!]
[ ] Mario Party 2 (E) [!]
[ ] Mario Party 2 (J) [!]
[ ] Mario Party 2 (U) [!]
[ ] Mario Party 3 (J) [!]
[ ] Mario Party 3 (U) [!]
[ ] Mega Man 64 (U) [!]
[ ] Micro Machines 64 Turbo (U) [!]
[ ] Micro Machines 64 Turbo (U) [a1][!]
[ ] Milo's Astro Lanes (E) [!]
[ ] Milo's Astro Lanes (U) [!]
[ ] Mischief Makers (E) [!]
[ ] Mischief Makers (U) [!]
[ ] Monaco Grand Prix (U) [!]
[ ] Monopoly (U) [!]
[ ] Monster Truck Madness 64 (E) [!]
[ ] Monster Truck Madness 64 (U) [!]
[ ] Mortal Kombat 4 (E) [!]
[ ] Mortal Kombat 4 (U) [!]
[ ] Mortal Kombat Trilogy (E) [!]
[ ] Mortal Kombat Trilogy (U) (V1.0) [!]
[ ] Mortal Kombat Trilogy (U) (V1.2) [!]
[ ] MRC - Multi Racing Championship (E) [!]
[ ] MRC - Multi Racing Championship (J) [!]
[ ] MRC - Multi Racing Championship (U) [!]
[ ] Ms. Pac-Man Maze Madness (U) [!]
[ ] Mystical Ninja 2 - Starring Goemon (E) [!]
[ ] Nagano Olympic Hockey '98 (E) [!]
[ ] Nagano Olympic Hockey '98 (U) [!]
[ ] Nagano Winter Olympics '98 (J) [!]
[ ] Nagano Winter Olympics '98 (U) [!]
[ ] NASCAR 2000 (U) [!]
[ ] NASCAR 99 (E) [!]
[ ] NASCAR 99 (U) [!]
[ ] NBA In the Zone 2 (J) [!]
[ ] NBA In the Zone '98 (J) [!]
[ ] NBA In the Zone '98 (U) [!]
[ ] NBA In the Zone '99 (U) [!]
[ ] NBA Jam 2000 (E) [!]
[ ] NBA Jam 2000 (U) [!]
[ ] NBA Jam 99 (E) [!]
[ ] NBA Jam 99 (U) [!]
[ ] NBA Pro 98 (E) [!]
[ ] NBA Pro 99 (E) [!]
[ ] Neon Genesis Evangelion (J) [!]
[ ] NFL Blitz 2001 (U) [!]
[ ] NFL Quarterback Club 2000 (E) [!]
[ ] NFL Quarterback Club 2000 (U) [!]
[ ] NFL Quarterback Club 2001 (U) [!]
[ ] NHL Blades of Steel '99 (U) [!]
[ ] Ohzumou 64 2 (J) [!]
[ ] Paper Mario (U)
[ ] Paperboy (E) [!]
[ ] Paperboy (U) [!]
[ ] Pawapuro Puroyakyu 4 (Power Baseball 4) (J) [!]
[ ] Pawapuro Puroyakyu 5 (Power Baseball 5) (J) [!]
[ ] PGA European Tour (E) [!]
[ ] PGA European Tour (U) [!]
[ ] Pilotwings 64 (E) [!]
[ ] Pilotwings 64 (J) [!]
[ ] Pilotwings 64 (U) [!]
[ ] Pocket Monsters Stadium (J) [!]
[ ] Pocket Monsters Stadium 2 (J) [!]
[ ] Pokemon Snap Station - Kiosk (U) [!]
[ ] Pokemon Stadium (E) [!]
[ ] Pokemon Stadium (F) [!]
[ ] Pokemon Stadium (G) [!]
[ ] Pokemon Stadium (S) [!]
[ ] Pokemon Stadium (U) [!]
[ ] Pokemon Stadium 2 (E) [!]
[ ] Pokemon Stadium 2 (U) [!]
[ ] Pokemon Stadium GS (J) [!]
[ ] Pro Yak Yu King Baseball (King of Pro Baseball) (J) [!]
[ ] Puzzle Bobble 64 (J) [!]
[ ] Quake II (E) [!] (PJ v1.2 recommended)
[ ] Quake II (U) [!] (PJ v1.2 recommended)
[ ] Quest 64 (U) [!]
[ ] Racing Simulation - Monaco Grand Prix (E) [!]
[ ] Racing Simulation 2 (G) [!]
[ ] Rakuga Kids (E) [!]
[ ] Rakuga Kids (J) [!]
[ ] Rally '99 (J) [!]
[ ] Rally Challenge 2000 (U) [!]
[ ] Rampage - World Tour (E) [!]
[ ] Rampage - World Tour (U) [!]
[ ] Rat Attack (E) [!] (PJ v1.2 recommended)
[ ] Rat Attack (U) [!] (PJ v1.2 recommended)
[ ] Rayman 2 - The Great Escape (E) [!]
[ ] Rayman 2 - The Great Escape (U) [!]
[ ] Ready 2 Rumble Boxing (E) [!] (PJ v1.2 recommended)
[ ] Ready 2 Rumble Boxing (U) [!] (PJ v1.2 recommended)
[ ] Ready 2 Rumble Boxing Round 2 (U) [!] (PJ v1.2 recommended)
[ ] Roadsters (E) [!]
[ ] Robotron 64 (E) [!]
[ ] Robotron 64 (U) [!]
[ ] Rocket - Robot on Wheels (E) [!]
[ ] Rocket - Robot on Wheels (U) [!]
[ ] Rockman Dash (J) [!]
[ ] RR64 - Ridge Racer 64 (E) [!]
[ ] RR64 - Ridge Racer 64 (U) [!]
[ ] Rugrats - Scavenger Hunt (U) [!]
[ ] Rugrats - Treasure Hunt (E) [!]
[ ] Rugrats in Paris - The Movie (U) [!]
[ ] Rush 2 - Extreme Racing USA (E) [!]
[ ] Rush 2 - Extreme Racing USA (U) [!]
[ ] S.C.A.R.S. (E) [!]
[ ] S.C.A.R.S. (U) [!]
[ ] San Francisco Rush - Extreme Racing (E) [!]
[ ] San Francisco Rush - Extreme Racing (U) [!]
[ ] San Francisco Rush 2049 (E) [!]
[ ] San Francisco Rush 2049 (U) [!]
[ ] Scooby-Doo - Classic Creep Capers (E) [!]
[ ] Scooby-Doo - Classic Creep Capers (U) [!]
[ ] Shadow Man (E) [!]
[ ] Shadow Man (F) [!]
[ ] Shadow Man (G) [!]
[ ] Shadow Man (U) [!]
[ ] Snow Speeder (J) [!]
[ ] Snowboard Kids (E) [!]
[ ] Snowboard Kids (U) [!]
[ ] Snowboard Kids 2 (E) [!]
[ ] Snowboard Kids 2 (U) [!]
[ ] Snowbow Kids (J) [!]
[ ] Sonic Wings Assault (J) [!]
[ ] South Park (E) [!]
[ ] South Park (G) [!]
[ ] South Park (U) [!]
[ ] Space Invaders (U) [!]
[ ] Spacestation Silicon Valley (E) [!]
[ ] Spacestation Silicon Valley (J) [!]
[ ] Spacestation Silicon Valley (U) [!]
[ ] Spider-Man (U) [!]
[ ] Star Fox 64 (J) [!]
[ ] Star Fox 64 (U) [!]
[ ] Star Soldier Vanishing Earth (J) [!]
[ ] Star Soldier Vanishing Earth (U) [!]
[ ] Starshot - Space Circus Fever (E) [!]
[ ] Starshot - Space Circus Fever (U) [!]
[ ] Super Mario 64 (E) [!]
[ ] Super Mario 64 (J) [!]
[ ] Super Mario 64 (U) (V1.0) [!]
[ ] Super Mario 64 Shindou Edition (J) [!]
[ ] Super Smash Bros. (A) [!]
[ ] Super Smash Bros. (E) [!]
[ ] Super Smash Bros. (U) [!]
[ ] Super Speed Race 64 (J) [!]
[ ] Superman (E) [!]
[ ] Superman (U) [!]
[ ] Tetris 64 (J) [!]
[ ] Tetrisphere (E) [!]
[ ] Tetrisphere (U) [!]
[ ] Tigger's Honey Hunt (E) [!]
[ ] Tigger's Honey Hunt (U) [!]
[ ] Tom and Jerry in Fists of Furry (E) [!]
[ ] Tom and Jerry in Fists of Furry (U) [!]
[ ] Tom Clancy's Rainbow Six (E) [!]
[ ] Tom Clancy's Rainbow Six (G) [!]
[ ] Tom Clancy's Rainbow Six (U) [!]
[ ] Tonic Trouble (E) [!]
[ ] Tonic Trouble (U) [!]
[ ] Tony Hawk's Pro Skater (E) [!]
[ ] Tony Hawk's Pro Skater (U) [!]
[ ] Tony Hawk's Pro Skater 2 (U) [UNK]
[ ] Top Gear Rally 2 (E) [!]
[ ] Top Gear Rally 2 (J) [!]
[ ] Top Gear Rally 2 (U) [!]
[ ] Turok - Dinosaur Hunter (E) (V1.0) [!]
[ ] Turok - Dinosaur Hunter (E) (V1.0) [a1]
[ ] Turok - Dinosaur Hunter (E) (V1.1) [!]
[ ] Turok - Dinosaur Hunter (E) (V1.2) [!]
[ ] Turok - Dinosaur Hunter (G) [!]
[ ] Turok - Dinosaur Hunter (J) [!]
[ ] Turok - Dinosaur Hunter (U) (V1.0) [!]
[ ] Turok - Dinosaur Hunter (U) (V1.1) [!]
[ ] Turok - Dinosaur Hunter (U) (V1.2) [!]
[ ] Turok - Legenden des Verlorenen Landes (Rage Wars) (G) [!]
[ ] Turok - Rage Wars (E) [!]
[ ] Turok - Rage Wars (U) [!]
[ ] Turok 2 - Seeds of Evil - Kiosk (U) [!]
[ ] Turok 2 - Seeds of Evil (E) [!]
[ ] Turok 2 - Seeds of Evil (G) [!]
[ ] Turok 2 - Seeds of Evil (U) [!]
[ ] Turok 3 - Shadow of Oblivion (E) [!]
[ ] Turok 3 - Shadow of Oblivion (U) [!]
[ ] Violence Killer - Turok New Generation (Seeds of Evil) (J) [!]
[ ] Virtual Chess 64 (E) [!]
[ ] Virtual Chess 64 (U) [!]
[ ] Virtual Pool 64 (E) [!]
[ ] Virtual Pool 64 (U) [!]
[ ] Waialae Country Club - True Golf Classics (E) [!]
[ ] Waialae Country Club - True Golf Classics (U) [!]
[ ] War Gods (E) [!]
[ ] War Gods (U) [!]
[ ] Wave Race 64 (E) [!]
[ ] Wave Race 64 (J) [!]
[ ] Wave Race 64 (U) (V1.0) [!]
[ ] Wave Race 64 (U) (V1.1) [!]
[ ] Wave Race 64 Shindou Edition (J) (V1.2) [!]
[ ] Wayne Gretzky's 3D Hockey (E) [!]
[ ] Wayne Gretzky's 3D Hockey (J) [!]
[ ] Wayne Gretzky's 3D Hockey (U) [!]
[ ] Wayne Gretzky's 3D Hockey '98 (E) [!]
[ ] Wayne Gretzky's 3D Hockey '98 (U) [!]
[ ] WCW Mayhem (U) [!]
[ ] Wetrix (E) [!]
[ ] Wetrix (J) [!]
[ ] Wetrix (U) [!]
[ ] Wheel of Fortune (U) [!]
[ ] Wild Choppers (J) [!]
[ ] WinBack - Covert Operations (E) [!]
[ ] WinBack - Covert Operations (J) [!]
[ ] Wonder Project J2 (J) [!]
[ ] WWF - War Zone (E) [!]
[ ] WWF - War Zone (U) [!]
[ ] WWF Attitude (E) [!]
[ ] WWF Attitude (G) [!]
[ ] WWF Attitude (U) [!]
[ ] Xena Warrior Princess - Talisman of Fate (E) [!]
[ ] Xena Warrior Princess - Talisman of Fate (U) [!]
[ ] Zelda no Densetsu - Toki no Ocarina (J) [!]
[ ] Zelda no Densetsu 2 - Mujura no Kamen (J) [!]


Total of 454 GoodN64 verified ReDumps (knwon good ROMs) supported, including 178 unique US titles.

Remember to check my web site (URL at top) for new INI releases, which should improve compatibility, as well as giving you the most complete guide to what's currently playable in PJ64.




3) IMPORTANT NOTES

Triple Buffering (video plugin option)
The aspect ratio (in this case, the height of the image) of quite a few games are affected by this setting. If you find the image OK in windowed mode, but too short or too tall when in fullscreen, try toggling this option. Note that triple buffering only applies to fullscreen modes!

Internal/External Transforms (video plugin option)
Quite a few graphics bugs are cleared up by using internal transforms. If you notice geometry position problems, try this. I _always_ use internal, Jabo's code is far more accurate than DX6.

MemPaks
Some of the games in the INI use the 'MemPak' (Controller Pack) to save. This save type is currently not working properly in PJ64, but good quality mempak emulation now comes courtesy of N-Rage's input plugin - simply check "RAW" in his plugin options and the plugin will take over MemPak duties from the emulator.

Self modifying code handling methods:
In my attempts to get games running as FAST as possible, it's always possible that I haven't set a sufficiently strong self modifying code handling method. If the core crashes, try running on Protect Memory to see if this is the case. Please let me know by email if you discover any such cases, so they can be corrected in the next release.

Testing & Stability
Games added in updated INIs are not as well tested as those in the earlier releases, for obvious reasons! They have passed some basic checks only (booting, graphics, sound, control, and stability for just a short while). So consider these updated INIs a public betatest of all the new games in PJ64.

Missing Region Name Variants
I try my best to find all different regions of each game. Sometimes this is difficult because for example the Japanese name, when translated into English, is different to the name the game has in the West. If I have missed any such cases, please email me the info. Try disabling Register Caching. Then try running on the interpreter. If it still crashes the core, only the authors can fix it, but please let me know anyway so i can at least correct future INI releases.

For a full guide please read the online FAQ.


4) TIPS

...did you know?

- PJ64 can load zipped ROMs, ROMs with spaces, and ROMs on a CD.
- You can edit the INI file through the PJ GUI (under "Settings").
- You can use safer INI settings to get through a crash point, state save, switch the settings back, state load, and continue your game.
- Changes to INI settings do not take effect until a ROM is rebooted.

PJ will automatically create new entries in the INI file or modify existing ones as appropriate. This is good (because it often saves you having to edit the file by hand) and this is bad (because you can mess up my existing settings and render previously working games unplayable).

If you find a game that used to work for you, no longer works (in the same version of PJ64 with the same plugins etc.), first check that you haven't altered the settings (i.e. replace your INI with the original), then do a clean reinstall of PJ64, remembering to clear registry settings with the .reg files provided.




5) THANKS

I want to say special thanks to:

Cowering and Master of Puppets, without whose tools this file would not be possible, and we'd all be in a world of shit. ;) Seriously, think about it...

The users on the forum, particularly mojo123 and bodie, for their feedback and compatibility lists, which are always very much appreciated when I'm updating the INI.

Last but definately not least, Zilmar and Jabo, for everything.


If you use PJ64 a lot and you want to thank the authors, you can do so by making a donation on the official website. Moneys are split 50-50 between Zilmar and Jabo.


If you use my INI file as a base for your own, and you want to release it, please:
1) Make it clear that it's unofficial
2) Use your own version numbering system (not "vX.X.XX")
3) Credit the PJ64 authors and myself. 

Thanks!

Smiff
1st September 2001
[EOF]