================================================
          Project64, by Zilmar and Jabo
            Copyright (c) 1998 - 2001
  The Premiere Nintendo64 emulator for Windows
================================================

--------
Overview
--------

Project64 is an emulator that has been in developlment for a couple of years. We are proud to allow other people to use the product that we have made for their enjoyment. Project64 features emulation of the Reality Signal Processor, which was reverse engineered by zilmar. This information has produced an accurate interpreter that has turned in to a recompiler by jabo, setting it apart from some of the emulators in development today. Another feature in Project64 is an accurate and fast Display Processor graphics core for OpenGL and Direct3D, developed by jabo over the last few years.

--------
Features
--------

Internally Project64 features two advanced recompilers, for the R4300i and the RSP respectively, both based off of zilmar's original interpreters. The R4300i interpreter is available as an alternative to the recompiler via settings.

- The R4300i recompiler is written by zilmar. It features dynamic block creation and advanced optimizations due to it's register caching core. It also has self-mod protection schemes   implemented to maximize compatibility and speed.

- The RSP recompiler is written by jabo. This compiler creates dynamic blocks of code, and optimizes the signal processor code through various code analysis techniques. It makes use of MMX and SSE to provide real-time emulation of this powerful co-processor.

Project64 uses high-level emulation for graphics, and low level emulation for audio. Jabo wrote Direct3D and OpenGL plugins for graphics, they have high quality blending and texturing, with several microcodes implemented from Mario64 to Zelda64 between the plugins. High level microcode emulation is optimized using SSE, and 3DNow!, and some parts of texturing have MMX optimizations.

-------------------
System Requirements
-------------------

Windows95 or higher, Pentium III 600Mhz or higher, DirectX 6.0 with a Direct3D compatible Accelerator, at least 16 megs of Video RAM. It may be possible to run with a slower system and if you find it useable on it then enjoy. DirectX 8.0a is strongly recommended as it is the latest release from microsoft and fixes issues.

*) Good video hardware: 

Riva TNT, Riva TNT2, GeForce, GeForce 2, ATI Radeon

*) Bad video hardware:

Matrox G200 and G400 - Some blending errors, the G400 looks decent, but don't expect perfection by any means.

ATI Rage Pro - It doesn't support constants, yet it does multi-texturing, this card looks very bad as a result.

3Dfx Voodoo Banshee - The drivers don't do it justice for Direct3D, in Glide this card is amazing, lots of blending errors here unfortunately, I doubt the drivers can be fixed.

*) Other Info:

General information - Some users reported disabling AGP Texturing in Direct3D via various advanced tweaking utilities availabe on the internet help fix lots of graphical glitches, this is probably due to poorly written drivers.

If you have a 3Dfx card, set your desktop to 16bpp, some 3Dfx cards don't do 32bpp Direct3D! Secondary devices (read: voodoo1, voodoo graphics, voodoo 2) are not supported by the graphics plugins included.

---------------
Saving in Games
---------------

PJ64 provides instant saves and saves like on the n64. Instant saves seem to work perfectly find in most cases but they are not perfect. It maybe possible to corrupt the n64 save you have with them. Test them out and see they should work with most games but we do not guarantee that they will work.

---------------
How to Use PJ64
---------------

PJ64 is a very easy emulator to use, open a rom and play a game. Look through the menus for the shortcut keys available, PJ has 11 save state slots for quick use. Most configuration is done through plugins, simplifying the main interface. Below is information on the plugins included with PJ64 only.

Direct3D and OpenGL:
--------------------

Texture type: High quality allows 32-bit textures which take more bus bandwith thus reducing the fill-rate on some cards, as well as uses up more texture memory on your video card.  Use this if performance isn't an issue, and you want the best possible quality textures.

Before resizing the window via the plugin it's recommended you pause emulation, while you don't have to always, it's just good practice so you don't crash anything.

OpenGL plugin isn't complete, use the Direct3D plugin usually. Direct3D FullScreen is implemented, and should work with no problems.

OpenGL Only:
------------

This plugin requires a NVIDIA brand card as it uses extensions only available on that card. It should work on a TNT, TNT2, and GeForce cards.

Direct3D Plugin Only:
---------------------

Transforms: The difference to the user between the pipelines really is hard to tell, since there isn't much, no matter what lighting is done internally, but transforms can be done either way, the internal one tends to be faster since it's highly optimized for SSE on a PentiumIII machine (there is a little kick in there for AMD 3DNow! as well). It's also important to mention the internal one works best on a GeForce for some reason.

IMPORTANT FOG NOTE: Make sure fog table emulation is enabled! if you own an NVIDIA card, you can do so in the NVIDIA display driver properties.

Validate Blending: because not all cards are made like a trusty Riva TNT, this option is the best choice for people experiencing white textures. It will not fix all problems, it may fix none at times, but if white graphics, leave this checked.

Frame Buffer Option - this setting is for advanced users only, it may fix graphical glitches in some games (Zelda64, Banjo-Kazooie, and Mario Kart) best left on Auto if you want to test something out, usually leave this off, it has negative impacts on performance.

Audio Plugin:
-------------

This plugin uses DirectSound and has a configurable buffer length. The shorter the buffer length the less lag the sound has, but it's more prone to audio being choppy if you have a slow machine. This plugin only plays the basic audio, but it works great when the RSP is processing the Audio data, producing top quality sound.

Input Plugin:
-------------

This plugin uses DirectInput, it has a fully configurable single player dialog. It supports lots of different game pads, and allows input from the keyboard at the same time.

Because the N64 has a large amount of buttons, a layout for one game may not be suitable for another. The profile feature solves this problem, it loads and save profiles for quick and easy access to different settings.

DeadZones - Some gamepads are not the most accurate devices, USB devices usually are the most accurate. This option can be considered a sensitivity control, increased deadzone makes it less sensitive, decreasing it makes it more sensitive to movement. This option is mostly dependent on the connection interface used (USB or gameport) and whether your device has analog stick capabilities, the default is a 25% deadzone.

RSP Plugins:
------------

MLE - "Middle level emulation" - Sends display lists to the graphics hle plugin, all other microcodes are emulated using the RSP recompiler.

HLE - "High level emulation" - Sends display lists to the graphics hle plugin, audio lists are sent to the audio hle plugin, this plugin performs no RSP emulation.

------------
Rom Settings
------------

You shouldn't need to modify the settings included with PJ64 for specific games, they should be setup for optimal performance by the INI author. However, here is a brief explanation of the settings.

Default Memory Size: Project64 supports "Expansion Memory", this is a toggle between 8 megs of memory or 4, obviously only select 8 if you know the game requires it so you don't use up memory.

Default Save Type: Should be left on default, if you know the details about a game's saving method than you can select the appropriate save type, again it's not necessary usually.

Self-mod Method: this setting has an impact on performance and compatibility. Protected memory is the most compatible, and None is the fastest. The other ones do different things and may result in better performance than Protected memory.

Max Speed: you can select a sync of 50 or 60 fps here if desired.

Always use TLB: this is a compiler switch that some roms require, but some do not. Additional performance may be obtained by turning this switch off for roms that do not require it.

The only thing not specified on a rom basis is register caching, this should be turned on always, however compatibility problems may be solved by turning this compiler optimization OFF.

--------------
Known Problems
--------------

Project64 is by no means perfect, there is some compatibility issues in terms of CPU, Graphics, and Audio that prevents games from functioning properly in various aspects. See our web site for a compatibility listing of games that are known to run with Project64.

-------------------
Contact the Authors
-------------------

All our plugins use the Project64 plugin specifications, see our website for details.

(!) Read this file entirely, use the message boards on the website for all feedback on PJ64, we do not have time to help people individually.

- No Rom requests, it's illegal, don't email to us either
- If you don't at least meet the min requirements, don't ask us for help
- Do not ask us when a specific game will work
- Do not ask us when the next version will be out, or what features it will have
- Do not ask us about plugins we didn't write, contact the proper author
- Do not report problems with using our plugins in other emulators
- Do not ask if your system will work, for help with it, or if we will support your hardware
- Do not email us files without permission

no exceptions, if you want to ask these questions try a messageboard at our website. 
http://www.pj64.net, also available at http://pj64.emulation64.com

jabo@emulation64.com
zilmar@emulation64.com

------------------
Credits and Greets
------------------

We would like to thank the following people for their support and help, in no specific order.

hWnd, Cricket, F|RES, rcp, _Demo_, Phrodide, icepir8, TNSe, gerrit, schibo, Azimer, Lemmy, LaC, Anarko, duddie, Anarko, Breakpoint, StrmnNrmn, slacka, smiff

As well as the people we have forgotten.

-------------------
Standard Disclaimer
-------------------

The N64 is a registered trademark of Nintendo, same goes for other companies mentioned above, or their products.

The authors are not affiliated with any of the companies mentioned, this software may be distributed freely as long as the original archive and software included is not modified any way or distributed with ROM images.

You use this software at your own risk, the authors are not responsible for any loss or damage resulting from the use of this software. If you do not agree with these terms do not use this software, simple.

[EOF]