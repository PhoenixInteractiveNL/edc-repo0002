Hyper64

Aimed to become the fastest C64 Emulator.
It's powered by a 6510-to-X86 Dynarec Engine.

1. introduction
---------------

Hyper64 is a working proof-of-concept of an experimental C64 emulator implementation without resorting to a conventional CPU emulation, but instead utilizing a realtime dynamic recompilation engine � which disassembles, analyzes and re-assembles the 6510 machine code as native 32-bit x86 code. It further uses a fast translation code cache.

The A, X and Y registers of the 6510 are mapped to the x86 AL, BL and CL registers and the 6510 flags are mapped via the x86 SAHF/LAHF opcodes.

Although this yields to a lot of speed emulation-wise, it also has the side-effect of not being cycle exact, but instead only being accurate on an instruction basis.

The VIC II emulation is � as far as I'm sophisticated � complete but also not cycle exact. The same thing applies to the CIA emulation, whose accuracy is based on a VIC II line basis.

2. minimum specs
----------------

  - normal modern cpu (p3 400 MHz or faster)
  - 128 megabytes of ram
  - a NT-based operating system (NT,2k,2k3,XP,etc.)

3. credits
----------

  c64 emulator code by bero

4. keys
-------

alt+f4           = exit
f9               = load diskette/image/etc. (press always first f9 reset please)   
f10              = nmi   
f11              = frame skipping between 1 frames and 50 frames switch 
shift+f11        = sid on/off (default off) 
f12              = hard reset
shift+f12        = speedthrotting on/off (default off) 
alt+enter        = fullscreen on/off
numpad ,         = switch between joy1 and joy2
numpad           = joystick control
numpad +         = increment frameskipping frames
numpad -         = decrement frameskipping frames

5. bugs+hints
-------------

  bero/farbrausch
  over and out.


