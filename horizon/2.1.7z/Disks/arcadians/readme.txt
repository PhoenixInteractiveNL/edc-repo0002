insert into drive 0

then press shift+break (F12) to auto boot

select "Use ZX as Caps Lock/Ctrl" under Input menu