#!/bin/sh
mvn site
