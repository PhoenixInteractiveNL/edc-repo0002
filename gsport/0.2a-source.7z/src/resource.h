//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gsport32.rc
//
#define IDD_ABOUT_DIALOG                101
#define IDC_GSPORT32                    102
#define IDR_TOOLBAR                     103
#define IDD_DLG_DISKCONF                104
#define IDR_ACCEL                       105
#define IDD_GSPORT32_KEY                106
#define ID_TOOLBAR                      5000
#define ID_STATUSBAR                    5001
#define IDC_EDIT_S5D1                   10051
#define IDC_EDIT_S5D2                   10052
#define IDC_EDIT_S6D1                   10061
#define IDC_EDIT_S6D2                   10062
#define IDC_EDIT_S7D1                   10071
#define IDC_EDIT_S7D2                   10072
#define IDC_BTN_S5D1                    11051
#define IDC_BTN_S5D2                    11052
#define IDC_BTN_S6D1                    11061
#define IDC_BTN_S6D2                    11062
#define IDC_BTN_S7D1                    11071
#define IDC_BTN_S7D2                    11072
#define ID_HELP_ABOUT                   40001
#define ID_FILE_EXIT                    40002
#define ID_FILE_DISK                    40003
#define ID_FILE_SENDRESET               40004
#define ID_FILE_JOYSTICK                40005
#define ID_FILE_DEBUGSTAT               40006
#define ID_FILE_SENDREBOOT              40007
#define ID_FILE_FULLSCREEN              40012
#define ID_FILE_SPEED                   40013
#define ID_HELP_KEY                     40014
#define ID_SPEED_1MHZ                   50001
#define ID_SPEED_2MHZ                   50002
#define ID_SPEED_FMHZ                   50003

#define IDD_SPEEDDIALOG                 117
#define IDC_SLOW                        1007
#define IDC_CUSTOM                      1008
#define IDC_EDITCUSTOM                  1009
#define IDC_NORMAL                      1010
#define IDC_FASTEST                     1011

#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
