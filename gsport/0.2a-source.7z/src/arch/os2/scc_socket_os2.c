/* scc_socket_driver.c */
void scc_socket_init(int port)
{}

void scc_socket_change_params(int port)
{}

void scc_socket_empty_writebuf(int port, double dcycs)
{}

void scc_socket_fill_readbuf(int port, int space_left, double dcycs)
{}