To compile this source code you will need Microsoft Visual C.NET.
Be sure to update your compiler with the latest service pack.

In the Configuration Manager are 4 build configurations:

Release (default)            = 1964 final public build. This is the build for end-users.
Release with .NET debugging  = Permits you to use the .NET debugger.
Release with Opcode Debugger = This is my debugger that compares interpretive opcodes
				to dyna ops and barks at you if there are any discrepancies.
Debug                        = 1964's N64 Debugger.

If you have source code related questions or If you
want to hire one of us for a job in this difficult job market,
you may leave us an email. If you have any other questions,
please use our messageboard.

1964 is copyright 1999-2002 by 

schibo - Joel Middendorf 
schibo@emulation64.com

and Rice
rice1964@yahoo.com

http://1964emu.emulation64.com
or http://www.1964emu.com