1964 Initialization File v1.8 Readme
v0.8.0 Compliant by Duncan

Tested System Spec's:
1.8 GHZ P4
256 MBRAM
Geforce 2 4x (64 MB Video Ram)
Windows XP
Sound Blaster Live

Plug-In's:
Jabo's Direct3D7 v1.40
Jabo's Direct Sound v1.40, (Zilmar's RSP LLE plugin used/checked)
Jabo's Direct Input7 v1.40

*Note* "Video Speed Sync - F6" was used/checked

------------------------------- [Rom Browser Notes] ------------------------------------

Playable! = game is playable with little or no errors.
-Almost Playable- = game has gfx errors that make it not fully playable, but may be played.
<Not Playable> = game does boot/start but has severe gfx errors making it unplayable.
+Not Working+ = game will not boot/start, or show any gfx.

(use PJ64.rdb): use the "Project64.rdb" file from PJ64, or the included custom "Project64.rdb" file in your 1964 directory/folder, its used for resolution fixes and plugin functions for game enhancement. *Note* You should use the included custom PJ64.rdb file, as it has custom settings, fixes, and additions that are NOT in the orig. PJ64.rdb, and are just for 1964.

(use Azimers Audio 040, no audio fix): use Azimers Audio plugin v040/v030 (old driver) and make sure the "audio fix" option is un-checked.

(use Frame Buffer: Emulate Clear option): in Jabos Direct3D6 & 7, under Video Settings/Advanced, select "Emulate Clear" next to: Frame Buffer Emulation.

(force Normal Blending): in Jabos Direct3D6 & 7, under Video Settings/Advanced, check the "Force Normal Blending".

(use NRage's DI 8 v1.61): use NRages Direct Input 8 v1.61, due to problems with Jabos Direct Input 7 v1.40 with few games.

(use Glide64 v0.1): use Glide64 v0.1, as some games were not playable with Jabos Direct3D7 v1.40, but playable or better with Glide64. If you dont have a Voodoo based video card, use eVoodoo3 or eVoodoo XP (Glide Wrappers).

(use 1964 OpenGL 4.1.0): use 1964 OpenGL 4.1.0, as some games were not playable with Jabos Direct3D7 v1.40, but playable or better with the 1964 OpenGL plugin.

------------------------------- [Special game Fixes/Notes] ----------------------------------

[Spacestation Silicon Valley (E) and (U) is playable]
Heres how to play SSV (E), which currently has a freezing problem:

Use 1964's OpenGL Plugin v4.1.0 and start the game,
Now Save (F5) at the "start" screen where the ship is flying around,
Exit the game, and change back to Jabo's Direct 3D7 v1.40,
Now start the game and load (Ctrl+L) the save and play.

[Jet Force Gemini (U) (f1) is playable]
Heres how to play (the cracked version) Jet Force Gemini (U) (f1):

Use PJ64 and start the game, then make a save state at the title/start screen,
Now put the save state in the "save" folder in the 1964 folder,
Now boot up Jet Force Gemini (U) (f1) in 1964 and use the "Import PJ64 Save State" feature,
Load the save state and play away.

[Gauntlet Legends (U) [!] playable]
Heres how to play Gauntlet Legends (U) [!]:

Start the game in 1964 as usual and go to the point where it hangs/freezes (over the first circle) and make a state save (F5) just as you begin to transport (spin) when the light come out, and close the game,
Now start up 1964 but this time use Zilmar's CFB plugin,
Start the game and load the save state you just made, you'll hear a low voice talking, now make another save (F5),
Start your Gauntlet Legends (U) [!] game as normal (with Jabos Direct3D plugin), load in the save state, and play away.

[Tom Clancy's Rainbow Six (U) and (E) Playable]
Make sure to use NRage's Direct Input8 v1.61 plugin, and use the Analog Stick for walking/movement control, and make sure to assign the Digital Pad buttons and use the "left" digital pad button for brightness.

----------------------------------- [Whats New] ---------------------------------------

- Full GoodN64 names are now shown in the rom browser (tested ones).
- All game specific "Save Types" (primary, secondary) are set by default.
- Many newly supported games.
- Numerous fixes: sound problem in Zelda OOT/crashing, freeze when hitting another car in Ridge Racer 64, etc., speed issues, sound fixes, resolutions corrected (many).

