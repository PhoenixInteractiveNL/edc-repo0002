//switches to control compiler

//#define ASSUME_ALWAYS_ALIGNED 1