// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#ifndef _STDAFX_H_
#define _STDAFX_H_

#define WINVER 0x0400

#include <dinput.h>
#include <mmsystem.h>
#include "resource.h"
#include "resrc1.h"

#include "config.h"
#include "controller.h"
#include "di.h"
#include "stdio.h"

bool IsRomOpened();

#endif
