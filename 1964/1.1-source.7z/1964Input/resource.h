//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 1964Input.rc
//
#define IDS_VERSION                     1
#define IDS_VERSION_DEBUG               2
#define IDD_ABOUTBOX                    101
#define IDD_CONFIGURATION               1000
#define IDC_COMBO_TYPE                  1000
#define IDC_COMBO_DEVICE                1000
#define IDC_BUTTON_KEY_SETTING          1001
#define IDC_COMBO_CONTROLLER            1002
#define IDD_DIALOG_KEYBOARD_SETTING     1002
#define IDC_BUTTON_ABOUT                1003
#define IDD_DIALOG_JOYSTICK_SETTING     1003
#define IDC_BUTTON_TEST                 1004
#define IDC_BUTTON_DEFAULT              1005
#define IDD_DIALOG_TEST                 1005
#define IDC_BUTTON_TRIGGER_Z            1006
#define IDC_LABEL_TRIGGER_Z             1007
#define IDC_BUTTON_TRIGGER_LEFT         1008
#define IDC_LABEL_TRIGGER_LEFT          1009
#define IDC_BUTTON_TRIGGER_RIGHT        1010
#define IDC_LABEL_TRIGGER_RIGHT         1011
#define IDC_BUTTON_A                    1012
#define IDC_LABEL_A                     1013
#define IDC_BUTTON_B                    1014
#define IDC_LABEL_B                     1015
#define IDC_BUTTON_C_UP                 1016
#define IDC_LABEL_C_UP                  1017
#define IDC_BUTTON_C_DOWN               1018
#define IDC_LABEL_C_DOWN                1019
#define IDC_BUTTON_C_LEFT               1020
#define IDC_LABEL_C_LEFT                1021
#define IDC_BUTTON_C_RIGHT              1022
#define IDC_LABEL_C_RIGHT               1023
#define IDC_BUTTON_START                1024
#define IDC_LABEL_START                 1025
#define IDC_BUTTON_STICK_UP             1026
#define IDC_LABEL_STICK_UP              1027
#define IDC_BUTTON_STICK_DOWN           1028
#define IDC_BUTTON_STICK_UPDOWN         1028
#define IDC_LABEL_STICK_DOWN            1029
#define IDC_BUTTON_STICK_LEFT           1030
#define IDC_LABEL_STICK_LEFT            1031
#define IDC_BUTTON_STICK_RIGHT          1032
#define IDC_BUTTON_STICK_LEFTRIGHT      1032
#define IDC_LABEL_STICK_RIGHT           1033
#define IDC_BUTTON_PAD_UP               1034
#define IDC_LABEL_PAD_UP                1035
#define IDC_BUTTON_PAD_DOWN             1036
#define IDC_LABEL_PAD_DOWN              1037
#define IDC_BUTTON_PAD_LEFT             1038
#define IDC_LABEL_PAD_LEFT              1039
#define IDC_BUTTON_PAD_RIGHT            1040
#define IDC_LABEL_PAD_RIGHT             1041
#define IDC_CHECK_INVERSE_STICK_UPDOWN  1042
#define IDC_COMBO_STICK_UPDOWN          1043
#define IDC_STATIC_VERSION              1044
#define IDC_STATIC_LOG                  1060
#define IDC_BUTTON_LAUNCH               1064
#define IDC_STATIC_DISPLAYING           1065
#define IDC_EDIT_LOG                    1069
#define IDC_EDIT_CHAT                   1071
#define IDC_BUTTON_CHAT                 1072
#define IDC_CHECK_SMOOTH                1073
#define IDC_CHECK_SMOOTHX               1074
#define IDC_CHECK_SMOOTHY               1075
#define IDC_CHECK_INVERSE_STICK_LEFTRIGHT 1076
#define IDC_COMBO_STICK_LEFTRIGHT       1077

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1035
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1075
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
