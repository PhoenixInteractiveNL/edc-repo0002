//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 1964Input.rc
//
#define IDS_VERSION_DEBUG               2
#define IDD_JOYSTICK                    1004
#define IDD_GUI                         1004
#define IDC_COMBO1                      1076
#define IDC_N64_CONTROLLER              1076
#define IDC_COMBO2                      1078
#define IDC_DEVICES                     1078
#define IDC_CHECK1                      1079
#define IDC_STICK_X                     1080
#define IDC_STICK_Y                     1081
#define IDC_AXIS_X_LABEL                1082
#define IDC_AXIS_Y_LABEL                1083

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1035
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1084
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
