#include "state.h"

CState::CState(){}

CState::~CState(){}