#include "Registers.h"

namespace N64
{
	CRegisters::CRegisters(void)
	{
	}

	CRegisters::~CRegisters(void)
	{
	}
}