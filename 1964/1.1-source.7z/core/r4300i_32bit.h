extern void r4300i_lwl_32bit(uint32 Instruction);
extern void r4300i_lwr_32bit(uint32 Instruction);