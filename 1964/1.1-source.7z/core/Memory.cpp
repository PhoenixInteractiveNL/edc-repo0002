#include "Memory.h"

CMemory::CMemory(void)
{
}

CMemory::~CMemory(void)
{
}
