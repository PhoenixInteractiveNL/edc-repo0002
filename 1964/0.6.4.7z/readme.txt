1964 0.6.4
==========

1964 Requires at least DirectX 8.0a. If you have Windows XP, 
you should already have DirectX 8.1. DirectX drivers can be downloaded at:
http://www.microsoft.com/directx/homeuser/downloads/default.asp
You also need a sound card with its drivers enabled.

While 1964 is very compatible, there are of course still games that do not yet run.
If you want to play Goldeneye, use PJ64, Nemu, or UltraHLE. The same goes for Majora's
Mask, it plays the intro only. Don't bother to download 1964 if you can't handle that.

Games are labeled in the ini as Playable if the user has the available means to
play the game. This means that if the plugins provided with 1964 are to-date inadequate
for a game, other plugins are available on the internet to enhance its playability. If
you have issues getting a game to work, or other problems, use the messageboard.
The messageboard link is provided on the 1964 web site: http://1964emu.emulation64.com.

For some games, like the Turok series, the easiest way to get them working is to use
zilmar's Basic Audio Plugin. If you want nice graphics and sound, consult the messageboard
and the linked FAQs.

Highly Recommended Plugins:
Jabo's Direct3D: Available with PJ64. http://www.pj64.net
Azimer's Audio: Available with Apollo and/or separately at http://apollo.emulation64.com
Input: Nrage Plugin, TR64 input, NooTe DI, SJR's input plugin. Consult the following links
for additional information:

Official 1964 User's Guide by Raymond     :  http://1964emu.emulation64.com/FAQ/1964_Main.html
Unofficial 1964 FAQ by Bobbi of ngemu.com :  http://help.ngemu.com
Help with cheat codes by DSF              :  http://1964emu.emulation64.com/cheats.htm
N64 Emulation Support Centre by Smiff     :  http://www.smiff.clara.net

The above links provide excellent information for getting the most out of 1964 and 64
emulation.


What's New in Brief
===================

- Improved compatibility and bug fixes
- Improved stability, user interface, and speed - including a new fast TLB method
- New memory model
- Speed sync
- Tons of new cheats by DSF
- New DirectInput plugin by NooTe (requires DirectX8.0a or newer)



We'd like to thank the following people for their help with 1964 0.6.4:
- Raymond for his great 1964 user's manual and help with the ini
- DSF for the mucho cheats and game hints
- All beta testers who have given feedback
- Always zilmar, Jabo, Azimer and everyone else in "the channel"

enjoy,
- schibo and Rice
http://1964emu.emulation64.com