1964 Initialization File v1.8 Readme
v0.8.0 Compliant by Duncan

Tested System Spec's:
1.8 GHZ P4
256 MBRAM
Geforce 2 4x (64 MB Video Ram)
Windows XP
Sound Blaster Live

Plug-In's:
Jabo's Direct3D7 v1.40
Jabo's Direct Sound v1.40, (Zilmar's RSP LLE plugin used/checked)
Jabo's Direct Input7 v1.40

*Note* "Video Speed Sync - F6" was used/checked

------------------------------- [Rom Browser Notes] ------------------------------------

Playable! = game is playable with little or no errors.
-Almost Playable- = game has gfx errors that make it not fully playable, but may be played.
<Not Playable> = game does boot/start but has severe gfx errors making it unplayable.
+Not Working+ = game will not boot/start, or show any gfx.

(use PJ64.rdb): use the "Project64.rdb" file from PJ64, or the included custom "Project64.rdb" file in your 1964 directory/folder, its used for resolution fixes and plugin functions for game enhancement. *Note* You should use the included custom PJ64.rdb file, as it has custom settings, fixes, and additions that are NOT in the orig. PJ64.rdb, and are just for 1964.

(use Azimers Audio 040, no audio fix): use Azimers Audio plugin v040/v030 (old driver) and make sure the "audio fix" option is un-checked.

(use Frame Buffer: Emulate Clear option): in Jabos Direct3D6 & 7, under Video Settings/Advanced, select "Emulate Clear" next to: Frame Buffer Emulation.

(force Normal Blending): in Jabos Direct3D6 & 7, under Video Settings/Advanced, check the "Force Normal Blending".

(use NRage's DI 8 v1.61): use NRages Direct Input 8 v1.61, due to problems with Jabos Direct Input 7 v1.40 with few games.

(use Glide64 v0.1): use Glide64 v0.1, as some games were not playable with Jabos Direct3D7 v1.40, but playable or better with Glide64. If you dont have a Voodoo based video card, use eVoodoo3 or eVoodoo XP (Glide Wrappers).

(use 1964 OpenGL 4.1.0): use 1964 OpenGL 4.1.0, as some games were not playable with Jabos Direct3D7 v1.40, but playable or better with the 1964 OpenGL plugin.

(use DaedalusD3D8): use DaedalusD3D8, as some games were not playable with Jabos Direct3D7 v1.40, but playable or better with the DaedalusD3D8 plugin.

------------------------------- [Special game Fixes/Notes] ----------------------------------

[Spacestation Silicon Valley (E) and (U) is playable]
Heres how to play SSV (E), which currently has a freezing problem:

Use 1964's OpenGL Plugin v4.1.0 and start the game,
Now Save (F5) at the "start" screen where the ship is flying around,
Exit the game, and change back to Jabo's Direct 3D7 v1.40,
Now start the game and load (Ctrl+L) the save and play.

[Jet Force Gemini (U) (f1) is playable]
Heres how to play (the cracked version) Jet Force Gemini (U) (f1):

Use PJ64 and start the game, then make a save state at the title/start screen,
Now put the save state in the "save" folder in the 1964 folder,
Now boot up Jet Force Gemini (U) (f1) in 1964 and use the "Import PJ64 Save State" feature,
Load the save state and play away.

[Gauntlet Legends (U) [!] playable]
Heres how to play Gauntlet Legends (U) [!]:

Start the game in 1964 as usual and go to the point where it hangs/freezes (over the first circle) and make a state save (F5) just as you begin to transport (spin) when the light come out, and close the game,
Now start up 1964 but this time use Zilmar's CFB plugin,
Start the game and load the save state you just made, you'll hear a low voice talking, now make another save (F5),
Start your Gauntlet Legends (U) [!] game as normal (with Jabos Direct3D plugin), load in the save state, and play away.

[Tom Clancy's Rainbow Six (U) and (E) Playable]
Make sure to use NRage's Direct Input8 v1.61 plugin, and use the Analog Stick for walking/movement control, and make sure to assign the Digital Pad buttons and use the "left" digital pad button for brightness.

----------------------------------- [Whats New] ---------------------------------------

- Full GoodN64 names are now shown in the rom browser (tested ones, 800+).
- All game specific "Save Types" (primary, secondary) are set by default.
- Many newly supported games.
- Now supports (G), (F), (I), (S), and (J) region roms.
- Numerous fixes: sound problem in Zelda OOT/crashing, freeze/hang when hitting another car in Ridge Racer 64, etc., speed issues, sound fixes, resolutions corrected (many).
- All (PD) roms are tested and most all are supported.

*Note* Theres alot more supported games (regions), fixes and optimizations than is listed below, ive lost track of them all with the testing of over 800+ roms.

----------------------------- [Newly Supported Games] ------------------------------


Bass Racing Ecogear Power Worm Championship
Beast Wars Metals
Bust-A-Move 2 - Arcade Edition
Centre Court Tennis
Chameleon Twist 2
Excitebike 64
Extreme-G XG2
F1 Racing Championship
Fighting Cup
Fighting Force 64
G.A.S.P! Fighter's NEXTream
Gauntlet Legends
Hot Wheels Turbo Racing
Jet Force Gemini
J. League Live 64
J. League Eleven Beat 1997
King Hill 64 - Extreme Snowboarding
Madden NFL 2002
Major League Baseball Featuring Ken Griffey Jr.
NASCAR 99
NBA Courtside 2 - Featuring Kobe Bryant
NBA In The Zone '99
Neon Genesis Evangelion
NFL Blitz
NHL 99
NHL Pro 99
Polaris Sno Cross
Powerpuff Girls, The - Chemical X-traction
Rally '99
Razor Freestyle Scooter
Re-Volt
Rockman Dash
Virtual Pro Wrestling 2
WinBack - Covert Operations
Wonder Project J2
World Cup 98
WWF - War Zone
WWF Attitude

------------------------------ [PAL Resolution Corrections] --------------------------

1080 Snowboarding (E) [!]
AeroGauge (E) [!]
All-Star Baseball 2000 (E) [!]
All-Star Baseball 99 (E) [!]
Armorines - Project S.W.A.R.M. (G) [!]
Armorines - Project S.W.A.R.M. (E) [!]
Banjo-Kazooie (E) [!]
BattleTanx - Global Assault (E) [!]
Bass Hunter 64 (E) [!]
Blues Brothers 2000 (E) [!]
Bomberman Hero (E) [!]
Bust-A-Move 3 DX (E) [!]
Castlevania - Legacy of Darkness (E) [!]
Chameleon Twist 2 (E) [!]
Charlie Blast's Territory (E) [!]
Chopper Attack (E) [!]
Command & Conquer (E) [!]
Command & Conquer (G) [!]
Conker's Bad Fur Day (E) [!]
Cruis'n USA (E) [!]
Cruis'n World (E) [!]
Diddy Kong Racing (E) (V1.0) [!]
Diddy Kong Racing (E) (V1.1) [!]
Disney's Tarzan (E) [!]
Disney's Tarzan (F) [!]
Disney's Tarzan (G) [!]
Donald Duck - Quack Attack (E) [!]
Donkey Kong 64 (E) [!]
Doom 64 (E) [!]
Dual Heroes (E) [!]
Duke Nukem 64 (E) [!]
Duke Nukem - ZER0 H0UR (E) [!]
Earthworm Jim 3D (E) [!]
ECW Hardcore Revolution (E) [!]
Excitebike 64 (E) [!]
Extreme-G XG2 (E) [!]
Extreme-G (E) [!]
F-Zero X (E) [!]
F-1 Pole Position 64 (E) [!]
F-1 World Grand Prix II (E) [!]
F1 Racing Championship (E) [!]
FIFA 99 (E) [!]
FIFA Soccer 64 (E) [!]
FIFA - Road to World Cup 98 (E) [!]
G.A.S.P! Fighter's NEXTream (E) [!]
Gauntlet Legends (E) [!]
Gex 64 - Enter the Gecko (E) [!]
Gex 3 - Deep Cover Gecko (E) [!]
Glover (E) [!]
GoldenEye 007 (E) [!]
Hercules - The Legendary Journeys (E) [!]
Hexen (E) [!]
Holy Magic Century (E) [!]
Holy Magic Century (F)
Holy Magic Century (G) [!]
Hybrid Heaven (E) [!]
Hydro Thunder (E) [!]
International Superstar Soccer 2000 (E) [!]
International Superstar Soccer 64 (E) [!]
International Superstar Soccer '98 (E) [!]
International Track and Field Summer Games (E) [!]
Jeremy McGrath Supercross 2000 (E) [!]
Jet Force Gemini (E) [!]
Killer Instinct Gold (E) [!]
Knockout Kings 2000 (E) [!]
Kirby 64 - The Crystal Shards (E) [!]
Legend of Zelda 2, The - Majora's Mask (E) (M4) [!]
Legend of Zelda, The - Ocarina of Time (E) (V1.1) [!]
Legend of Zelda, The - Ocarina of Time (E) (V1.0) [!]
Kobe Bryant's NBA Courtside (E) [!]
Looney Tunes - Duck Dodgers (E) [!]
Lylat Wars (A) [!]
Lylat Wars (E) [!]
Mace - The Dark Age (E) [!]
Madden Football 64 (E) [!]
Magical Tetris Challenge (E) [!]
Magical Tetris Challenge (G) [!]
Mario Golf (E) [!]
Mario Party (E) [!]
Mario Party 2 (E) [!]
Mario Party 3 (E) [!]
Mario Tennis (E) [!]
Mickey's Speedway USA (E) [!]
Milo's Astro Lanes (E) [!]
Mischief Makers (E) [!]
Monster Truck Madness 64 (E) [!]
Mortal Kombat 4 (E) [!]
Mortal Kombat Mythologies - Sub-Zero (E) [!]
Mystical Ninja - Starring Goemon (E) [!]
Mystical Ninja 2 - Starring Goemon (E) [!]
NBA Hangtime (E) [!]
NBA In the Zone 2000 (E) [!]
NBA Jam 2000 (E) [!]
NBA Jam 99 (E) [!]
NBA Live 99 (E) [!]
NBA Pro 98 (E) [!]
NBA Pro 99 (E) [!]
NFL Quarterback Club 2000 (E) [!]
NHL Breakaway 99 (E) [!]
NHL Breakaway 98 (E) [!]
NHL Pro 99 (E) [!]
Nuclear Strike 64 (E) [!]
Off Road Challenge (E) [!]
Paperboy (E) [!]
Paper Mario (G) [!]
Penny Racers (E) [!]
PGA European Tour (E) [!]
Pokemon Puzzle League (E) [!]
Pokemon Puzzle League (F) [!]
Pokemon Puzzle League (G) [!]
Pokemon Snap (A) [!]
Pokemon Snap (G) [!]
Pokemon Snap (F) [!]
Pokemon Snap (A) [!]
Quake 64 (E) [!]
Quake II (E) [!]
Racing Simulation - Monaco Grand Prix (E) [!]
Racing Simulation 2 (G) [!]
Rampage - World Tour (E) [!]
Rampage 2 - Universal Tour (E) [!]
Rayman 2 - The Great Escape (E) [!]
Resident Evil 2 (E) [!]
RR64 - Ridge Racer 64 (E) [!]
San Francisco Rush 2049 (E) [!]
Shadowgate 64 - Trials of the Four Towers (E) [!]
Shadow Man (G) [!]
Shadow Man (E) [!]
Shadow Man (F) [!]
South Park - Chef's Luv Shack (E) [!]
Spacestation Silicon Valley (E) [!]
Star Wars Episode I - Racer (E) [!]
Star Wars Episode I - Battle for Naboo (E) [!]
Star Wars - Shadows of the Empire (E) [!]
Super Smash Bros. (E) [!]
Super Smash Bros. (A) [!]
Tetrisphere (E) [!]
Tigger's Honey Hunt (E) [!]
Tom and Jerry in Fists of Furry (E) [!]
Tonic Trouble (E) [!]
Top Gear Hyper-Bike (E) [!]
Top Gear Overdrive (E) [!]
Turok 3 - Shadow of Oblivion (E) [!]
Turok 2 - Seeds of Evil (E) [!]
Turok 2 - Seeds of Evil (G) [!]
Twisted Edge Extreme Snowboarding (E) [!]
Waialae Country Club - True Golf Classics (E) [!]
Wave Race 64 (E) [!]
Wayne Gretzky's 3D Hockey '98 (E) [!]
Wayne Gretzky's 3D Hockey (E) [!]
WinBack - Covert Operations (E) [!]
WCW Mayhem (E) [!]
Wetrix (E) [!]
World Cup 98 (E) [!]
World is Not Enough, The (E) [!]
WWF Attitude (E) [!]
WWF No Mercy (E) (V1.0) [!]
WWF No Mercy (E) (V1.1) [!]
WWF - War Zone (E) [!]
WWF Attitude (E) [!]
WWF Attitude (G) [!]
WWF WrestleMania 2000 (E) [!]
Xena Warrior Princess - Talisman of Fate (E) [!]
Yoshi's Story (E) [!]


--------------------------- [NTSC Resolution Corrections] --------------------------

All-Star Baseball 99 (U) [!]
All-Star Baseball 2000 (U) [!]
All-Star Baseball 2001 (U) [!]
Banjo-Kazooie (U) [!]
Banjo to Kazooie no Dai Bouken (J) [!]
Armorines - Project S.W.A.R.M. (U) [!]
Battlezone - Rise of the Black Dogs (U) [!]
Bass Hunter 64 (U) [!]
Bio Hazard 2 (J) [!]
Bottom of the 9th (U) [!]
Brunswick Circuit Pro Bowling (U) [!]
Clay Fighter - Sculptor's Cut (U) [!]
Command & Conquer (U) [!]
Conker's Bad Fur Day (U) [!]
Diddy Kong Racing (J) [!]
Diddy Kong Racing (U) (V1.0) [!]
Diddy Kong Racing (U) (V1.1) [!]
Disney's Donald Duck - Goin' Quakers (U) [!]
ECW Hardcore Revolution (U) [!]
Eltale Monsters (J) [!]
Fox Sports College Hoops '99 (U) [!]
Gauntlet Legends (U) [!]
Gauntlet Legends (J) [!]
Jeremy McGrath Supercross 2000 (U) [!]
Madden Football 64 (U) [!]
Mario Party (J) [!]
Mario Party (U) [!]
Mario Tennis (J) [!]
Mario Tennis (U) [!]
Ms. Pac-Man Maze Madness (U) [!]
Mystical Ninja - Starring Goemon (U) [!]
NBA Hangtime (U) [!]
NBA Jam 2000 (U) [!]
NBA Jam 99 (U) [!]
NBA Live 99 (U) [!]
New Tetris, The (U) [!]
NFL Blitz (U) [!]
NFL Blitz 2000 (U) [!]
NFL Blitz 2001 (U) [!]
NFL Blitz - Special Edition (U) [!]
NFL Quarterback Club 2000 (U) [!]
NFL Quarterback Club 2001 (U) [!]
NHL Breakaway 99 (U) [!]
NHL Breakaway 98 (U) [!]
Off Road Challenge (U) [!]
Quest 64 (U) [!]
Rayman 2 - The Great Escape (U) [!]
Resident Evil 2 (U) [!]
San Francisco Rush 2049 (U) [!]
South Park (U) [!]
Star Soldier Vanishing Earth (J) [!]
Star Soldier Vanishing Earth (U) [!]
Triple Play 2000 (U) [!]
Turok - Rage Wars (U) [!]
Turok 3 - Shadow of Oblivion (U) [!]
Turok 2 - Seeds of Evil (U) [!]
Violence Killer - Turok New Generation (J) [!]
WCW Mayhem (U) [!]
WWF Attitude (U) [!]
WWF - War Zone (U) [!]
Xena Warrior Princess - Talisman of Fate (U) [!]
