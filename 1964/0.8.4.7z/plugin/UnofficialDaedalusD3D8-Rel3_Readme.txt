Unofficial Daedalus D3D8 Release 3 Readme
=========================================
Minor fixes for better use with 1964.



Unofficial Daedalus D3D8 Release 2 Readme
=========================================
A. What's new:
1. Better frame buffer supports
2. Better texture alignment.
3. New games and new ucodes supported.
4. Full screen
5. Remember setting options
6. A lot of other stuffs that I can not remember


B. New Games Supported:
	-	Yoshi Story, full playable
	-	Resident Evil 2, almost playable, Zbuffer problem
	-	Star Craft,	playable
	-	DKR, almost playable
	-	EVA64, full playable
	-	Ogre Battle 64, playable
	-	New Tetris, playable
	-	Dr. Mario, almost playable
	-	Banjo Tooie, full playable, Banjo's shadow is hacked and working
	- 	Other games could be supported better because of the new features of this plugin

C. Game Issues Fixed:
	-	Toy Story 2 menu
	-	Bug's Life menu
	-	Pokemon Stadium, menu images
	-	Paper Mario pause screen
	-	Mario tennis shadow, almost working
	-	Mario tennis, screen changes
	-	Others	


D. Known Bugs and Issues:
- RE2 zbuffer issue. RE2 is using depth image, my GF2 MX400 does not support lockable depth buffer, so I can not implement this feature
- If you are using "Faster" as "frame buffer setting", if you have some depth buffer problems in some game, try to use "disable" as "frame buffer setting"
- DKR is not playable
- CBFD, PD, Jet Force Gemini, Mickey's Speedway are not supported.



E. Options:
1. Win Frame Mode
   Using WinFrame mode instead of fill mode, you will see only lines instead of solid square.
2. Fast Text CRC
   This is an old option, will be removed in the further. 
   By selecting it, the plugin will do some cheat regarding texture CRC checking, it is faster, but you will likely have some texture problems.
   Suggest not to use it.
3. Enable Hacks
   The plugin is using many hacks, some hacks are working for some games but not others, try to use this option to see if you can have the game running better.
4. Frame Buffer Setting
   Please see the frame buffer setting section because this is an important setting
5. Disable Color Combiner
6. Normal Color Combiner
   Use normalized color combiner setting, should make the plugin working better on cheap video cards which do not support advanced color combiner modes.
7. Enable Alpha Blender
   If disabled, will use normalized alpha blender setting
8. Enable Big Images
   Some of the GBI2 games are using a lot of big images, the plugin is getting very slow for these games, you can disable it by using this option to make your game running faster. Of course you will lose some textures.
   PS: This option is getting less important because plugin has been able to support these big images better.
9. Scale Image
   Enable this option if you have some texture alignment problems. It will be a little slower.
10.Smart Screen Update, will detect frame buffer switching and do screen update by that time. If you are using FLIP frame buffer type, be sure to use this option. A few games will be just black screen without this option.




F. Frame Buffer Type and Setting:
1. Frame Buffer Types:
   Double Buffer Copy is the default one, you can try other one
   When using triple buffer types, if the game is flicking, try to use the "Smart Update" setting

2. Frame Buffer Setting:
a. Disable	-	Don't nothing special handling for N64 frame buffer
b. Copy		-	Copy DX8 frame buffer to N64 frame buffer memory, Banjo's puzzle piece screen need this. This setting is very slow, but you have to use it at some time. At least it is important to play Banjo Tooie.
c. Faster	-	Plugin will simulate frame buffer in a faster and cheap way, working for most games like Yoshi story, Pokemon, Dr. Mario
d. Faster+Recheck -	I know Mario Tennis selecting screen is using this when changin to the next screen. This option will check the frame buffer memory using and will copy DX8 frame buffer to N64 frame buffer when the N64 frame buffer memory is used as source as textures.
e. Complete	-	The plugin will create a fake render target if extra N64 frame buffer is used, and will copy the fake render target back to N64 RDRAM frame buffer when it is done. You can try this to play Yoshi Story, not as good as the Faster option for Yoshi, and it is slow.
f. Ignore	-	Will watch any usage of N64 extra frame buffer, but will ingore primitives written into the extra frame buffer.
g. With Emulator -	Emulator will help plugin to detect frame buffer read / write. I have extended Zilmar's video plugin spec, and added three functions for such purpose. 1964 0.8.4 rc1 does not support it. Only my private version of 1964 and newest Daedalus D3D8 plugin support. Banjo and Dr. Mario need it very much, but it also causes problem in other games.

If you have any question regarding N64 frame buffer and extra frame buffer, ask your questions on emutalk.com


G. Credits
   Too many to list.

--------------------------------------------
By Rice/1964 - Aug. 7, 2002
Co-author of 1964, the Nintendo 64 Emulator
rice1964@yahoo.com
