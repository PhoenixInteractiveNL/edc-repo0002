This is the plugin folder. In this folder you can put all the dll input, audio, and video files.
IMPORTANT: Do NOT remove any of the following files from this folder:

1964ogl.dll
NooTe_DI.dll
steb_aud.dll
Null_Snd.dll

These are the default plugins and 1964 expects to see them.

Note: zlib.dll is not considered a plugin. It belongs in your root 1964 folder.

-schibo
  


zlib is Copyright (C) 1995-1998 Jean-loup Gailly and Mark Adler
  Jean-loup Gailly        Mark Adler
  jloup@gzip.org          madler@alumni.caltech.edu

1964 is in no way affiliated with, endorsed by, or supported by Nintendo.
Nintendo, Nintendo64, and the N64 logo are trademarks of Nintendo.

