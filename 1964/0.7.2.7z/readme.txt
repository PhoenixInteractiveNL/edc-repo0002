1964 0.7.2 Readme
January 05, 2002


To Get the Most out of Your 1964, Read This:
============================================

For advanced users, read Advanced_Users.txt.

Visit http://1964emu.emulation64.com. There you will find the latest downloads of 1964 
and additional links to the messageboards and faq's.


Requirements:
DirectX 8.x
PIII 600 MHz or comparable Athlon Processor (sweet)
NVidia Geforce2+ card highly recommended
Windows XP/NT/ME/98/2000
128MB RAM or better recommended


[ Graphics ]

The latest build of 1964 features a very fast advanced recompiling engine, which means that many games
can be played at really nice speeds, but you're not gonna enjoy it much with our OpenGL plugin.
Admittedly, our OpenGL graphics plugin in its current condition is not that great..
(primitive is a more kind way of putting it). It is our weakness and we don't plan on doing anything to 
it until next year. Fortunately, in the meantime, since several n64 emus share a compatible plugin spec,
you can mix and match plugins from other emulators. We recommend that you download Jabo's Direct3D
plugin which is available with PJ64. Go to http://www.pj64.net and download pj64. The filename will be
"plugin/Jabo_Direct3D.dll" or similar. You can take this dll file and place it in the plugin subfolder
in "1964". Then, from the plugin menu, you can choose Jabo's plugin in 1964.


[ Audio and Input ]

When you first start 1964, the basic plugins will be used so that 1964 can start.
If you have the requirements to run 1964 properly, Choose Azimer Audio 0.30 (old driver)
for audio. Azimer's 0.40 beta will sound a lot better overall and has great mp3 sound 
for games like Conker, but it is slower than the 0.30 build.
Jabo's audio plugin does NOT work in 1964.

Use either NooTe_DI plugin for input (provided with 1964),
NRage's input plugin, or SJR's input plugin. <- 1964 now supports the full
mempak/rumblepak/etc in the 2 latter plugins that support it.


[ Rom Browser ]

If you do not see a list of games in your window when you start 1964, then your Rom Folder has not yet
been configured. Go to File->Change Folder and browse for the path to your games. When the rom list 
refreshes, you can now easily choose a game from the window. By default, the Rom Browser is set to 
automatically update the folder path after you choose your first game from the "File->Load ROM...". 
After this, your Rom browser should be updated.


[ Cheats ]
For help with game cheats and to download the latest cheat code database, 
please visit http://dsf.emulation64.com


[ NetPlay ]

1964 uses kaillera for netplay and in all honesty, it really isn't worth the headache of configuring it, 
unless you are on a LAN. Netplay can be tricky to configure, but if you're eager to play Mortal Kombat 
or MarioKart networked, here's how to do it. Use at your own risk. When you get it working, it is fun.

- Kaillera reads the network game list from your selected Rom Folder. If you do not have a rom folder 
configured, or if you are unaware, read the section above entitled [ Rom Browser ].
- Using NooTe's DirectInput plugin in 1964, assuming 2 computers, each computer will need both controller1 and controller2 enabled.
- DO NOT enable the kaillera that is built into the input plugin. While it will work, it is slower than
the kaillera that is built into the 1964 core.
- Download the kaillera server from www.kaillera.com. Run the kaillera server on one of your machines.
- Know what the server's IP address is.
- From the File menu in 1964, choose "NetPlay...". Kaillera will start.
- Set keyframes to LAN (60 FPS). (necessary?)
- Click the "Enter IP" button and enter the server's ip number. This will bring you to a private chat session.
- Create a game, the game list should be made available when you press the create button.

- From another machine run 1964 and choose "Netplay..."
- Set keyframes to LAN (60 FPS). (necessary?)
- Click the "Enter IP" button and enter the server's ip number. This will bring you to a private chat session
with player 1 (server).
- When Player 1 has created a game, you will see it in your kaillera window. Select the game name and then click
"Join". 

- After Player 2 has joined the game, player 1 presses start game.
- Pray.
- Repeat.


[ What's new in 0.7.2 ]

- 1964 support for mempak/rumblepak in N-Rage and SJR input plugins
- A few emulation bug fixes.
- Experimental 32bit core compiler option. Read Advanced_Users.txt for more information.
- Plenty more speed.
- Optional cpu usage profile stats are viewable in the status bar to see r4300i %,
video %, audio %, and idle %
- Enhancements and bug fixes to the GUI.


1964 Team is 
Rice and schibo - 1964 Development
< schibo@emulation64.com >
< rice1964@yahoo.com >

Cheats: DSF < dsfarad@yahoo.com >
FAQ: Raymond
Input plugin, zip support: NooTe

For additional help, please visit the EmuTalk forums at http://www.emuhelp.com

1964 is hosted by Emulation64 - http://www.emulation64.com
Also visit http://www.ngemu.com
http://www.hosthq.net/~emuxhaven/
http://www.emuhq.com/