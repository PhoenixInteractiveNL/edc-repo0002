To uninstall 1964, simply double-click the .reg file that corresponds
to your operating system. Then delete the 1964 folder.
