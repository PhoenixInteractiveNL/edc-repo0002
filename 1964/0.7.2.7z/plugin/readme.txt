Last Updated: 4:49 PM 1/4/2002

Audio Plugin Readme
-------------------

-------------------------------------------------------------

Please notice:
  This plugin was tested to run only on PJ64.  Any use of 
this plugin on any other emulator may have undesired results.  
Use at your own risk.

-------------------------------------------------------------

Usage:
  Unzip the contents of this archive into the Plugin directory in the destination
emulator's directory. (ie. C:\Emulators\Apollo\Plugin)

-------------------------------------------------------------

RELEASE NOTES:
  Please don't bug me about the Audio being choppy or being off.  If you want,
I will release a version to hook Jabo's Audio DLL.  But other then that,
your emails will be ignored.
  Keep in mind I developed this plugin on a 1.4Ghz ThunderBird.  If you have a
lesser system and this plugin completely blows... then don't use it.  I don't
care.
  This is a private project.  You are welcome to use the plugin and distribute
it with any emulator, given you keep this readme.txt in the SAME directory as
the plugin.  Special note: I HIGHLY RECOMMEND creating AiUpdate in its -=OWN=-
thread with Wait set to TRUE.  My plugin's audio code relies on this heavily 
and may faulter if this condition is not met.

-------------------------------------------------------------

What's New:
-----------
- v0.40  - Rewrote ABI 3 Envelope Mixer Completely (Fixed Super Smash Bros Missing Sounds)
         - Solved endianess issue with the Save/Load Buffers (Fixed Paper Mario Static and in others)
         - Bugs #3 and #9 Fixed
         - Wrote MP3 Audio in HLE (Not buggy) :)

- v0.30  - Finished new Envelope Mixer for ABI 1 and ABI 3 (ABI 3 is still buggy)
         - Fixed bug that surfaced in v0.21.  Many more roms shouldn't die on boot.
         - Added many hacks to be able to play RSP Audio in all roms I own (not reliable)
         - Added OldStyle v0.21 Audio option... Here for compatibility only
         - Added MP3 Audio (Buggy... I warned you!!!)
         - Fixed Configuration Dialog bug (should only crash if you change the buffer without pausing)
	 - Potentially Fixed a Problem in ABI 2???

- v0.21  - Fixed a bug in the GAIN command for ABI 2 (Bug #8 Fixed)
         - Fixed problem with "INTER2" in ABI 2 (Bug #4 and #6 Fixed)
         - Went back to Audio Code Revision 1.1 temporarily...

- v0.20  - Rewrote the Direct Sound Code (Discontinued using zilmar's code)
         - Added Fill Audio option to hopefully smooth out audio a little bit for
           those who are just below audio play time.
    "  b - Fixed problem with some Audio Cards (Audio Code Revision 1.1)
         - Added Registery Settings
         - Found a little bit of speed hidden in the dll file
       c - Added Audio Code Revision 2.0

- v0.13  - Fixed the issue in MKT, Robotron, Cruisin USA, Rampage World Tour, and some others.
    "  b - Fixed a problem with the Interleave... - Thanks to LaC for clarifying
	 - Fixed bad VADPCM decompression with the 4:1 compression ratio. Skull Kid is fine :)
	 - Halved the size of the DLL file...  cut out all the garbage.
	 - Went back to standard C calling convention.  Fastcall caused too many issues...

- v0.12b - I decided to include this small readme.txt for all maintenance releases.
	 - Added some code to help prevent the plugin from erroring out when a rom is closed.
	 - Made the AiHack enabled by default (It's preferred in most situations)
	 - Added some safeguards to prevent areas of code from clashing (due to threading).

Known Issues: (* - Indicates a resolved issue)
-------------
*1. Problem: Zelda MM "People Bug" - Skullkid and other people in the rom 
            sound funny.
   Solution: Been Fixed - 4:1 Ratio sample decompression error

*2. Mario64's Intro...
   Solution: Been Fixed - Interleave

*3. Problem: Paper Mario has a lot of static...
   Solution: Problem with Load Buffer and Save Buffer.  Endianess issue.

*4. Problem: Slight static in the Zelda MM town music
   solution: Problem with "INTER2" in ABI 2

*5. Problem: Buzzing in Banjo Kazooie
   Solution: Fixed in v0.20

*6. Problem: Buzzing in the high note in Zelda MM as a deku boy
   Solution: Problem with "INTER2" in ABI 2

*7. Problem: Audio all around sounds off.
   Solution: Fixed in v0.30 - This was because of the Envelope Mixer.

*8. Problem: Zelda MM some off music in that one shop in the town where the 
            two love birds are in the shop or is it a game?
   Solution: Problem in ABI2 GAIN command

*9. Problem: Super Smash Brothers is missing audio and the audio just doesn't sound right.
   Solution: Rewrote the Envelope Mixer

*10. Problem: Mario64's Star Zoom sound isn't very Zoomy...
   Solution: Fixed in latest Beta release... should Problem 10 never appeared public...

11. Problem: No sound in Super Smash Bros. (E) [Perhaps others as well]
   Solution: None.  Problem in the Audio Driver

Items finished for release:
---------------------------
- Paper Mario Fix
- Smash Bros. Fix
- New Envelop Mixer in ABI 3
- Fix the known issues
- MP3 Audio in ABI 3

Items Almost Finished:
----------------------


What's Next:
------------
- New Audio Driver with Unhacked processing of Audio (Extremely time frustrating thus far)
- Fix Unknown Issues


Future (priority from greatest to least):
-----------------------------------------
- Add MusyX
- Add Audio Filters
- Add Equilizer


Thanks,

-Azimer