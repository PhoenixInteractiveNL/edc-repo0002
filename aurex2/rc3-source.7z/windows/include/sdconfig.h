// $Id: sdconfig.h,v 1.1 2006/03/06 12:59:08 fumi Exp $

#ifndef SDCONFIG_H
#define SDCONFIG_H

#define HOST_IS_LITTLE_ENDIAN

#endif
