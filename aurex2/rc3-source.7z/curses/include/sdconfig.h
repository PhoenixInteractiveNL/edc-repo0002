// $Id: sdconfig.h,v 1.1 2006/03/06 12:59:08 fumi Exp $

#ifndef SDCONFIG_H
#define SDCONFIG_H

#define KEY_WITHOUT_PUSH_UP

#define OPTION_DEFAULT_AFTER_IMAGE true
#define OPTION_DEFAULT_ANTI_ALIAS  false
#define OPTION_DEFAULT_EXPANTION   1

#endif
