// -*-c++-*-
// $Id: bdffont.h,v 1.2 2004/05/03 18:00:49 fumi Exp $

#ifndef BDFFONT_H
#define BDFFONT_H


class BdfFont{
  public:
	int width;
	unsigned char *fontdata;
	int data_len;
};

#endif
