// $Id: emu_font.h,v 1.6 2005/01/08 09:40:31 fumi Exp $

#define mmpSITAYA		0x25D11B
#define mmpUEYA			0x25D10E
#define mmpRYA   		0x25CB14
#define mmpRYAs			0x25D128
#define mmpINFO			0x262CA4
#define mmpYN			0x2629F2
#define mmpYNb			0x263462
#define mmpGARA			0x262922


// �ɥ�ե���
#define mmpDR1			0x263E41
#define mmpDR2			0x263E75
#define mmpDR3			0x263EA9
#define mmpDR4			0x263EDD
#define mmpDR5			0x263F11
#define mmpDR6			0x263F45
#define mmpDR7			0x263F79
#define mmpDR8			0x263FAD
#define mmpDR9			0x263FE1
#define mmpDRa			0x264015
#define mmpDRb			0x264049
