/* $Id: emu_gaiji.h,v 1.2 2006/01/21 18:04:35 fumi Exp $ */

#define GAIJI_RIGHT_ARROW_BLACK 0xf89a
#define GAIJI_RIGHT_ARROW_WHITE 0xf89c
