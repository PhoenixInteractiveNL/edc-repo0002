// -*-c++-*-
// $Id: key.h,v 1.2 2004/04/29 09:44:32 fumi Exp $

#ifndef KEY_H
#define KEY_H

#include "keybuffer.h"

#endif
