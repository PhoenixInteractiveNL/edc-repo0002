/* -*-c++-*- */
// $Id: sdfindfile.h,v 1.3 2006/02/22 17:40:39 fumi Exp $

#ifndef SDFINDFILE_H
#define SDFINDFILE_H

class SDFindFile;

struct dta_t{
	SDFindFile *sdff;
	char _recived[18];
/* �� 22 byte ͽ���ΰ� */

//	struct rup_time time __attribute__ ((packed));
//	struct rup_day day __attribute__ ((packed));
	unsigned char time[2]  __attribute__ ((packed));
	unsigned char date[2]  __attribute__ ((packed));
	unsigned long size __attribute__ ((packed));
	unsigned char attrib;
	char filename[13];
};
/* 44 byte */

/*
 * �Ǥ���С�dta_area �ˤϷѾ����饹����ϥ������������ʤ������ɤ��褦�ʵ�������
 */
class SDFindFile
{
  protected:
	struct dta_t *dta_area;
	char const *pathname;
	unsigned char search_attribute;

  public:
	SDFindFile(struct dta_t *dta_area, char const *pathname, unsigned char search_attribute);
	virtual ~SDFindFile();

	virtual int findFirst(void) = 0;
	virtual int findNext(void) = 0;

	void setDate(int year, int month, int day);
	void setTime(int hour, int min, int sec);
};


#endif

