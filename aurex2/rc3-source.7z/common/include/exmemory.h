// -*-c++-*-
// $Id: exmemory.h,v 1.2 2004/04/29 09:44:32 fumi Exp $

#ifndef EXMEMORY_H
#define EXMEMORY_H

class ExMemory
{
  public:
	ExMemory(void);

	void native(void);
};

#endif

