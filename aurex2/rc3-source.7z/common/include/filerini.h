// -*-c++-*-
// $Id: filerini.h,v 1.3 2004/04/29 09:44:32 fumi Exp $

#ifndef FILERINI_H
#define FILERINI_H

#include "filerinibase.h"

class FilerIni : public FilerIniBase
{

};

#endif

