// -*-c++-*-
// $Id: throwable.h,v 1.1 2004/11/06 17:16:01 fumi Exp $

#ifndef THROWABLE_H
#define THROWABLE_H

class Throwable
{
};

#endif
