﻿using Jellyfish.Library;

namespace Jellyfish.Virtu
{
    public sealed partial class MainApp : ApplicationBase
    {
        public MainApp() :
            base("Virtu")
        {
            InitializeComponent();
            InitializeOutOfBrowserUpdate();
        }
    }
}
