﻿using System.Windows;

namespace Jellyfish.Virtu
{
    public sealed partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
