Genieous - EACE EG2000 Colour Genie emulator

� 2009-2011 Attila Gr�sz (gyros AT freemail DOT hu)
http://gaia.atilia.eu


What's a Colour Genie?
======================

The Colour Genie was the heavily modified offspring of the EACA VideoGenie.
It had 16 colours and were mounted with a CRTC display IC as well as a General Instruments 
AY-3-8910 PSG. Later revisions had modified colours, screen size as well as various 
expansions and an updated BASIC ROM.

The Colour Genie was marketed in Europe (UK/Germany) and also in New Zealand and Australia.

The current version of the emulator supports the unexpanded Colour Genie.


What's this thing I've just downloaded?
=======================================

Emulator, that imitates the behaviour of a piece of computer hardware
on another platform, in this specific case thus an 8-bit Colour Genie is 
emulated on the 32-bit Windows platform (natively).

Although two very good Colour Genie emulator exist, they are made to run under 
MS-DOS, are outdated and no longer maintained.

Genieous is freeware, and may be distributed freely if unaltered,
and the copyright notice is retained. As a consequence, the author take
no responsibilities whatsoever for any damage caused by this emulator. 
In short: use it at your own risk! 

Genieous aims to exploit the benefits of a graphical user interface
with features such as drag'n'drop, intuitive menus etc.

New releases of the emulator will be published on the following page:
http://gaia.atilia.eu


Features of the Genieous emulator
=================================

- full and cycle exact Z80 CPU core with NMI interrupt (RESET)
- partial CRTC 6545 emulation
- support for 16 and 32 kb memory setups
- 3 channel AY-3-8910 PSG emulation along with the noise and envelope 
  generators
- full keyboard emulation, with optional symbolic mapping
- read/write support for the CAS tape format
- read/write support for tape WAV format
- tape sound

Missing features of the emulator
================================

- I/O port on the YM2149/AY-3-8190 sound board is not emulated (printer & joystick)
- the CRTC emulation is incomplete
- disk emulation is broken

Usage
=====

Running
-------

To be able to run this program, minimum Windows 95 is needed.
No install is necessary, just copy the contents of the ZIP package
to a new folder and click on the executable called HT1080Z.

The simplest way to get programs started is with drag'n'drop or via
the File->Autostart menu option. When drag'n'dropping a disk image file,
keeping the Ctrl key down will reboot the emulated machine.


Command line options
--------------------

General format:

Genieous.exe [/a] [/d] [/h] [/i filename] [/m] [/w] [filename]

For now, only a few command line switches are supported:

/a        : suppress autostart of CAS and CMD images
/d        : enable double scan of screen lines
/h        : disables sound at startup (by default it's on)
/i        : insert diskimage on startup into drive:0
/m        : specify model (1, 2 or 3)
/w        : run the emulator with the maximum speed possible


Monitor
-------

The program has a simple built-in monitor/disassembler. By pressing
ESC[-APE] can this be entered. On pressing this button again, one
can return to the emulated machine. Further keyboard shortcuts:

F1        : Disassembly list from the actual value of the IP.
            On top of the page, the current state of the CPU is shown.
F2        : Memory map of the emulated machine
F4        : Set breakpoint at actual position
F7        : Run until here (if possible within a given amount of cycles)
ENTER     : Step one assembly instruction
PAGE UP   : One page up in the list
PAGE DOWN : One page down in the list
UP-ARROW  : One row upwards in the list
DOWN-ARROW: One row downwards in the list


Drive
-----

Although the WD1771 disk controller emulation is available, the images
do not appear to work. Only a couple of CGD images show a directory 
with the CMD"I" command.

In case someone knows the reasons, please contact me.


Tape
----

This was the most widespread and thus most important peripheral of
the Colour Genie.

Two major formats exist for tape emulation: CAS and WAV. 
Both are read-/writeable.

- WAV

This format can be used if one would like to transfer a program to 
the real machine. The result can be then played back via the sound
output of the PC to a tape and reloaded on the real machine.

For creating such WAV, one has to first choose 'Create WAV' from the
Tape menu, press PLAY/RECORD by selecting the appropriate menu point from
the Tape menu and issuing the necessary commands in the emulated machine 
(for example: CSAVE"NAME"). The saving process is done realtime (=slow)
but the process can be accelerated by pressing ALT+F3 that gives full
CPU power to the emulator on your machine. It is important that once the
save command has finished the tape must be stopped (via the Tape menu, by
ticking PLAY/RECORD off) and the WAV should be closed (very important!).

The Colour Genie used a 1200 baud tape recording frequency.

- CAS/CGD

Quicker and more efficient format, widespread in the TRS-80 world as well. It
is a literal byte-exact representation of what is written to a real tape
on a real Colour Genie. It is only slightly different from the 
TRS-80/VideGenie-I format.

Saving/loading of CAS files is done via ROM traps and hence it is 
not supporting custom loaders, but in return it is much quicker. Most
load and save operations finish in a snap. BASIC programs can be saved
with the CSAVE"NAME" command, in this case a pop-up window will appear where
you must fill in the name and location of the desired CAS image.

Saving a given memory location in CAS format is also possible via the file
menu. Here you must fill in the begin and the end of the memory area that is
about to be saved along with the start address which defaults to 0066h which
is the NMI entry point (soft RESET).

DOS extension
-------------

The emulator comes with support for the disk expanstion ROM. You can enable it via
the machine setup dialog window by selecting 'custom machine configuration'.


Thanks
======

I'd like to thank these people their help: info, testing, being nice, etc. :-)

* Terry Stewart,
* Reinhard Gansweith,
* people on the EACA mailing list

Links
=====

Wikipedia page on the Colour Genie
http://en.wikipedia.org/wiki/Colour_Genie

Terry Stewart's System-80 and EACA resource site:
http://www.classic-computers.org.nz/system-80/

Reinhard Gansweith's webpage on the Colour Genie (in German):
http://gansweith.freehostia.com/colourgenie/

File and document archive:
http://oldcomputers.dyndns.org/public/pub/rechner/EACA_GEN/

Changelog
=========

v1.0.2
------

- PC-joystick and gamepad support
- Centronics printer support (output sent to printer.txt)
- adjustable colour display saturation
- reenabled basic breakpoint support in the external monitor
- compiled statically against the Visual C++ runtime

v1.0.1
------

- custom Z80 CPU frequencies (between 500000 and 10 mln Hz)
- added original German character set
- improved and optimized display emulation

v1.0
----

- first public release
- ability to use custom ROMs
- CRTC
- AY-3-8190 (YM2149) sound emulation
- CAS tape format support (R/W)
- WAV tape format support (R/W)
- save screenshot in GIF format (when non 1-bit display)
- PAL blur
- TV interlace/double scan
- save emulator output to AVI video
- large window mode
- full screen mode
- paste text from the clipboard
- copy screen buffer to the clipboard
- settings saved in the registry
- drag'n'drop support
- support for command line options
- autostart emulator images (great for novice users)
- simulated keyboard input from external text files (BAS/TXT)
- selectable RAM size
- support for Northern and Southern versions of the machine
